"""Run pipeline stage 3."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.pipeline import stage

if __name__ == "__main__":
    stage(3)
