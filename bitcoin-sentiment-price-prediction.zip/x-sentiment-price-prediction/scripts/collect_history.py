"""Create a historical plan or validate local exports; never starts billable runs."""

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pandas as pd
from src.config import ROOT, load_config
from src.ingestion.history import make_plan, import_exports

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--days", type=int, default=180)
    parser.add_argument(
        "--end", help="Exclusive end day, YYYY-MM-DD; defaults to current UTC midnight"
    )
    parser.add_argument("--max-posts", type=int, default=20)
    parser.add_argument("--import-exports", action="store_true")
    args = parser.parse_args()
    c = load_config()
    folder = ROOT / "data/raw/history/exports"
    folder.mkdir(parents=True, exist_ok=True)
    plan = make_plan(args.days, args.end, args.max_posts)
    pd.DataFrame(plan).to_csv(ROOT / "reports/history_plan.csv", index=False)
    (ROOT / "data/raw/history/plan.json").write_text(json.dumps(plan, indent=2))
    print(
        f"Prepared {len(plan)} daily date-filtered queries. No network request or paid run was made."
    )
    if args.import_exports:
        mapping = json.loads((ROOT / c["apify_mapping_file"]).read_text())
        posts, coverage = import_exports(folder, mapping, plan)
        posts.to_csv(ROOT / "data/processed/historical_x_posts.csv", index=False)
        (ROOT / "reports/history_coverage.json").write_text(
            json.dumps(coverage, indent=2)
        )
        print(json.dumps(coverage, indent=2))
