"""Export only verified synthetic evaluation data for a public dashboard."""

import json
import shutil
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pandas as pd
from src.config import ROOT

if __name__ == "__main__":
    m = json.loads((ROOT / "reports/run_manifest.json").read_text())
    if m.get("demo") is not True:
        raise ValueError("Refusing to publish real data in the demo snapshot")
    collection = json.loads((ROOT / "data/processed/manifest.json").read_text())
    if collection != m:
        raise ValueError("Run all six demo stages before exporting a public snapshot")
    from src.ingestion.demo import generate

    expected_prices, _, _ = generate(m["config"])
    folder = ROOT / "demo_snapshot"
    folder.mkdir(exist_ok=True)
    with sqlite3.connect(ROOT / "data/database/market.db") as db:
        for table in ["prices", "features", "predictions", "backtest_results"]:
            df = pd.read_sql_query("SELECT * FROM " + table, db)
            if table == "prices":
                actual = df.copy()
                actual["timestamp"] = pd.to_datetime(actual["timestamp"], utc=True)
                pd.testing.assert_frame_equal(actual, expected_prices)
            if table == "features" and (
                pd.Timestamp(df.timestamp.min())
                != pd.Timestamp(m["first_cutoff"]) + pd.Timedelta(hours=24)
                or len(df) != m["price_rows"] - 24
            ):
                raise ValueError("Database does not match the demo manifest")
            df.to_csv(folder / (table + ".csv"), index=False)
    for name in [
        "ml_metrics.csv",
        "trading_metrics.csv",
        "folds.csv",
        "run_manifest.json",
        "evaluation_report.md",
        "current_sentiment_outlook.md",
    ]:
        shutil.copyfile(ROOT / "reports" / name, folder / name)
    print("Public synthetic dashboard snapshot updated")
