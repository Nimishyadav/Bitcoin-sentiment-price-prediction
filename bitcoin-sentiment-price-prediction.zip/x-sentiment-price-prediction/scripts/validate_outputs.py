"""Assert invariants on generated delivery artifacts."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import json
import pandas as pd
from src.config import ROOT
from src.database.db import TABLES, connect, read
from src.features.feature_engineering import TARGET_COLUMNS

if __name__ == "__main__":
    with connect() as db:
        existing = {
            r[0]
            for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")
        }
    assert TABLES <= existing
    f = read("features")
    p = read("predictions")
    assert set(TARGET_COLUMNS) <= set(f)
    assert set(p.horizon) == set(range(6))
    assert set(p.model) == {"linear", "tree", "persistence"}
    assert not p.duplicated(["timestamp", "horizon", "model"]).any()
    assert (
        p.target_timestamp - p.timestamp == pd.to_timedelta(p.horizon + 1, unit="h")
    ).all()
    folds = pd.read_csv(ROOT / "reports/folds.csv")
    assert (
        pd.to_datetime(folds.last_train_label, utc=True)
        < pd.to_datetime(folds.test_start, utc=True)
    ).all()
    for name in ["ml_metrics", "trading_metrics"]:
        assert len(pd.read_csv(ROOT / f"reports/{name}.csv")) == 18
    figures = list((ROOT / "reports/figures").glob("*.png"))
    assert len(figures) == 14 and all(x.stat().st_size > 1000 for x in figures)
    assert (ROOT / "reports/evaluation_report.md").stat().st_size > 5000
    m = json.loads((ROOT / "reports/run_manifest.json").read_text())
    if m["demo"]:
        assert "SYNTHETIC" in (ROOT / "reports/evaluation_report.md").read_text(
            encoding="utf-8"
        )
    result = {
        "status": "PASS",
        "mode": "DEMO" if m["demo"] else "REAL",
        "sqlite_tables": len(TABLES),
        "feature_rows": len(f),
        "target_columns": TARGET_COLUMNS,
        "prediction_rows": len(p),
        "walk_forward_folds": len(folds),
        "figures": len(figures),
    }
    (ROOT / "reports/validation.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
