"""Run all stages in order."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.pipeline import stage

if __name__ == "__main__":
    for number in range(1, 7):
        stage(number)
