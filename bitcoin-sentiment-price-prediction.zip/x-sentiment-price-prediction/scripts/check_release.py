"""Allowlisted GitHub release packaging with credential-value checks."""

import argparse
import json
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DIRECTORIES = [
    "src",
    "scripts",
    "tests",
    "config",
    "reports",
    "demo_snapshot",
    ".streamlit",
    ".github",
]
ROOT_FILES = [
    "app.py",
    "README.md",
    "DEPLOYMENT.md",
    "requirements.txt",
    "requirements-real.txt",
    "requirements-demo-lock.txt",
    ".env.example",
    ".gitignore",
    "pytest.ini",
]


def release_files():
    paths = [ROOT / name for name in ROOT_FILES if (ROOT / name).is_file()]
    for name in DIRECTORIES:
        paths.extend(
            p
            for p in (ROOT / name).rglob("*")
            if p.is_file()
            and not any(x in p.parts for x in ["__pycache__", ".pytest_cache"])
            and p.name != "secrets.toml"
        )
    return sorted(set(paths))


def verify(files):
    secret_values = []
    env = ROOT / ".env"
    if env.exists():
        for line in env.read_text(encoding="utf-8-sig").splitlines():
            if "=" in line:
                key, value = line.split("=", 1)
                if key.strip() in {"APIFY_API_TOKEN", "TAVILY_API_KEY", "EXA_API_KEY"}:
                    value = value.strip().strip("\"'")
                    if len(value) >= 8:
                        secret_values.append(value.encode())
    patterns = [
        rb"\bapify_api_[A-Za-z0-9_-]{16,}",
        rb"\btvly-[A-Za-z0-9_-]{16,}",
        rb"\bsk-[A-Za-z0-9_-]{20,}",
    ]
    for path in files:
        relative = path.relative_to(ROOT)
        if path.name in {".env", ".env.txt", "secrets.toml"}:
            raise ValueError("Private file in release: " + str(relative))
        content = path.read_bytes()
        if any(value in content for value in secret_values) or any(
            re.search(pattern, content) for pattern in patterns
        ):
            raise ValueError("Possible credential in release file: " + str(relative))
    m = json.loads((ROOT / "demo_snapshot/run_manifest.json").read_text())
    if m.get("demo") is not True:
        raise ValueError("Public dashboard snapshot must be synthetic")
    return {
        "status": "PASS",
        "files": len(files),
        "size_bytes": sum(p.stat().st_size for p in files),
        "private_env_included": False,
        "real_raw_posts_included": False,
        "dashboard_mode": "SYNTHETIC_DEMO",
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--zip", action="store_true")
    args = parser.parse_args()
    files = release_files()
    result = verify(files)
    if args.zip:
        folder = ROOT / "dist"
        folder.mkdir(exist_ok=True)
        with zipfile.ZipFile(
            folder / "x-sentiment-github.zip", "w", zipfile.ZIP_DEFLATED
        ) as archive:
            for p in files:
                archive.write(
                    p, Path("x-sentiment-price-prediction") / p.relative_to(ROOT)
                )
        result["archive"] = "dist/x-sentiment-github.zip"
    print(json.dumps(result, indent=2))
