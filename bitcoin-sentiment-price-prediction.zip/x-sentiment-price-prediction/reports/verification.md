# Local verification

- Final unit and Streamlit UI suite: **21 passed**.
- Five dashboard views and model/horizon controls verified with Streamlit AppTest.
- Live Streamlit localhost preview opened and visually inspected; screenshot at reports/dashboard_preview.png.
- Full synthetic demo stages 1–6 rerun successfully: 8 SQLite tables, 696 feature rows, six targets, 4,968 OOS predictions, 12 purged folds, 14 charts.
- Public demo snapshot exported from the completed demo run. No real raw posts are published.
- Historical planner generated 180 daily date queries without any paid/network request. Importer rejects out-of-window data and reports coverage; automatic Actor runs are disabled.
- Separate free Yahoo price request returned 4,303 raw bars with one hourly gap; real model training was not run.
- Release scanner checks private filenames, known configured token values, and token patterns. The ZIP includes only allowlisted project files.
- No GitHub upload, public deployment, paid Actor run or subscription was performed.
- .env, downloaded real posts, raw datasets, SQLite, logs, environments and caches are excluded from the release ZIP.

- Independent clean-ZIP smoke test: **21 tests passed** after extracting the release to a separate folder without .env or SQLite.
