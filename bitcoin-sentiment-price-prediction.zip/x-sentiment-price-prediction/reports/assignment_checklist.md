# Assignment delivery checklist

Status key: **Implemented/verified** = code plus local demo/tests; **Configured by user** = real API operation depends on credentials or a selected Actor. Real financial performance is not claimed.

| # | Requirement | Delivery / status |
|---|---|---|
| 1 | Asset | BTC-USD/Bitcoin default, environment override, requested 180-day real history; demo 30 days |
| 2 | Apify X | REST Actor launch/polling/pagination, raw JSONL, configurable dotted schema adapter; actual Actor/input/token must be supplied and validated by user |
| 3 | Prices | yfinance real loader, completed hourly UTC OHLCV, duplicate/order/validity/gap checks; real provider coverage not tested |
| 4 | Tavily | Required real news context integration, four searches, stored news; API key needed |
| 5 | Exa | Optional context integration, no training dependency; optional API key |
| 6 | Database | All eight SQLite tables generated, timestamp indexes, allowlisted identifiers, parameterized insert values |
| 7 | Sentiment | FinBERT real scorer, probability/score/label, model-content cache; real model download pending; explicit demo lexicon verified |
| 8 | Engagement | Fixed log caps and normalized weights, all requested aggregates; future engagement totals disabled in real historical mode |
| 9 | Alignment | UTC close cutoffs, exact-boundary test and future-post exclusion |
| 10 | Leakage | Six-bar train-label purge, train-only scaling, causal feature mutation test, news excluded; historical source revision bias documented |
| 11 | Features | Price/sentiment-only explicit feature list, 24h trailing stats and sentiment lags |
| 12 | Targets | Six columns, n+0 next close through n+5 six hours ahead; verified |
| 13 | Baselines | Persistence and LinearRegression plus HistGradientBoosting fallback tree |
| 14 | Six models | Independent per-horizon fits and OOS predictions for all three model families |
| 15 | Validation | Expanding chronological folds, configurable contiguous windows, fold boundaries and fold metrics saved |
| 16 | ML metrics | MAE, RMSE, R2, directional accuracy, counts and fold counts for all 18 pairs |
| 17 | Backtest | Threshold long/flat, next-open execution, non-overlapping holdings, two-sided fees/slippage |
| 18 | Trading metrics | Sharpe, Sortino, drawdown, total/annualized return, volatility, win rate; 8760/hour-duration annualization |
| 19 | Charts | All nine requested categories; 14 actual PNG outputs |
| 20 | Outlook | Dataset-cutoff score/change/ratios/volume/trend, context sources, restrained interpretation |
| 21 | Structure | Modular src/config/scripts/tests/data/reports/logs directories implemented |
| 22 | Config | YAML settings; interval intentionally limited to validated 1h and six horizons, documented as limitation |
| 23 | Environment | .env.example, no secret credentials supplied or embedded |
| 24 | Dependencies | Only used runtime/test libraries, bounded version ranges and exact tested demo lock |
| 25 | Errors | HTTP retries/429/timeouts, sanitized failures, missing/malformed data, insufficient windows, model failure; no silent real-to-demo fallback |
| 26 | Logging | File/console stage counts and folds under logs/ |
| 27 | Tests | 21 passing tests including all requested mathematical/leakage/split categories and API failure mocks |
| 28 | Reproducibility | Exact stage commands, seed, synthetic fixture, local environment, version manifest and demo lock |
| 29 | README | Architecture, methodology, setup/API instructions, actual synthetic results, limitations and security |
| 30 | Evaluation | Generated 21-section report with measured tables and embedded charts |
| 31 | Security | Secret-value scan, ignored .env, no credentials printed; no Git commit or upload performed |
| 32 | Storage/Git | Raw/processed/SQLite/cache/log/environment ignored; scripts reproduce outputs; lightweight report/figures retained |
| 33 | Demo | Credential-free deterministic complete pipeline, prominent synthetic labels |
| 34 | Quality | Modular Python, deterministic models, documented modules, explicit error handling; formatter applied |
| 35 | Feature constraint | Explicit sentiment + price allowlist; Tavily/Exa excluded |
| 36 | Final checks | Tests + full demo + SQLite/targets/predictions/folds/charts/report checks; reports/validation.json |
| 37 | Workflow | Empty folder inspected before implementation; implemented, tested, reviewed and documented |
| 38 | Final delivery | README, report, this checklist and delivery file inventory; real credentials/schema remain manual |

## Remaining manual setup / practical limits

- Supply Apify and Tavily credentials, chosen Actor ID, exact Actor input and output mapping. Exa key optional.
- Install full real-mode requirements and download FinBERT weights. Run a small Actor sample before requesting 180 days to confirm schema and cost.
- Real API integration is implemented against official contracts but was not exercised with a paid account. Successful demo is not proof that an arbitrary Actor is compatible.
- Only continuous hourly data is supported by the validated implementation. Other intervals require updating alignment, targets and annualization together.
- No serialized live model service, audited point-in-time archive or real profitability result is delivered. Historical post text availability and revisions remain data-source limitations.


## Streamlit and free-delivery update

- Five-view interactive Streamlit app (`app.py`), bundled synthetic snapshot, model/horizon controls and report/CSV downloads.
- Lightweight root dependencies for free demo hosting; optional real-model dependencies in `requirements-real.txt`.
- GitHub Actions test/demo workflow and clean source ZIP generated with `scripts/check_release.py --zip`.
- Historical local-export planner/importer, date validation and coverage checks. Automatic paid Actor runs disabled for the free workflow.
- Read `DEPLOYMENT.md` for local launch, GitHub upload and Streamlit Community Cloud deployment. Full 180-day real X history and real model results remain unavailable.
