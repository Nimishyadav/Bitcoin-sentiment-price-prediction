"""Free, read-only presentation dashboard. Start: streamlit run app.py."""

from pathlib import Path
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st
from src.dashboard import load_snapshot, equity_curves, SNAPSHOT

st.set_page_config(
    page_title="Signal / BTC sentiment research", page_icon="₿", layout="wide"
)
COLORS = ["#43D9BD", "#7C9CFF", "#FFBE70"]
MODEL_NAMES = {
    "tree": "Gradient boosting",
    "linear": "Linear regression",
    "persistence": "Persistence",
}
st.markdown(
    """<style>
.block-container {max-width:1440px;padding-top:6rem;padding-bottom:3rem;}
[data-testid="stMetric"] {background:#131e2d;border:1px solid #263449;border-radius:12px;padding:18px;}
[data-testid="stMetricLabel"] p {white-space:normal;overflow:visible;text-overflow:clip;}
.eyebrow {color:#43d9bd;font-size:12px;line-height:1.6;font-weight:700;letter-spacing:.14em;overflow-wrap:anywhere;}
.hero {font-size:clamp(30px,4.2vw,46px);line-height:1.2;font-weight:750;letter-spacing:-.035em;margin:12px 0 16px;overflow-wrap:break-word;}
.subtitle {color:#bdcbe0;font-size:17px;line-height:1.6;max-width:850px;margin-bottom:20px;}
@media (max-width:640px) {
  .block-container {padding-top:5rem;padding-left:1rem;padding-right:1rem;}
  [data-testid="stMetric"] {padding:12px;}
}
</style>""",
    unsafe_allow_html=True,
)


@st.cache_data(show_spinner=False)
def data():
    return load_snapshot()


def chart(fig):
    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font={"color": "#bdcbe0"},
        colorway=COLORS,
        margin=dict(l=10, r=15, t=42, b=15),
        legend=dict(orientation="h", y=1.13, x=0),
        height=380,
    )
    fig.update_xaxes(showgrid=False)
    fig.update_yaxes(gridcolor="#233044")
    st.plotly_chart(fig, width="stretch")


def metric_value(value, percent=False):
    if pd.isna(value):
        return "Undefined"
    return f"{value:.2%}" if percent else f"{value:.2f}"


try:
    bundle = data()
except (OSError, ValueError, KeyError) as exc:
    st.error(
        "Demo snapshot could not be loaded. Restore demo_snapshot/ from the repository or regenerate it using scripts/export_demo_snapshot.py."
    )
    st.stop()

manifest = bundle["manifest"]
features = bundle["features"]
with st.sidebar:
    st.markdown("## ₿ Signal")
    st.caption("SENTIMENT × PRICE RESEARCH")
    st.divider()
    section = st.radio(
        "Explore",
        [
            "Overview",
            "Forecast explorer",
            "Strategy lab",
            "Model comparison",
            "Methodology & report",
        ],
    )
    st.divider()
    model = st.selectbox(
        "Forecast model", list(MODEL_NAMES), format_func=lambda k: MODEL_NAMES[k]
    )
    horizon = st.select_slider(
        "Prediction horizon",
        options=list(range(6)),
        value=0,
        format_func=lambda h: f"n+{h} · {h+1} hour" + ("s" if h else ""),
    )
    st.caption("n+0 means the next hourly close. All timestamps are UTC.")
    st.divider()
    st.markdown("**Free presentation mode**")
    st.caption(
        "No account, API key or paid request. Uses a bundled synthetic run. Your private .env is never opened by this app."
    )

st.markdown(
    '<div class="eyebrow">BITCOIN / MULTI-HORIZON RESEARCH</div>',
    unsafe_allow_html=True,
)
st.markdown(
    '<div class="hero">The pulse behind the price.</div>', unsafe_allow_html=True
)
st.markdown(
    '<div class="subtitle">Explore X sentiment, six forecast horizons, and walk-forward performance in one research workspace.</div>',
    unsafe_allow_html=True,
)
st.warning(
    "DEMO · All prices, posts, forecasts and performance shown here are synthetic. This is a software demonstration, not a live Bitcoin forecast."
)
st.caption(
    f"BTC-USD · Hourly · {manifest['first_cutoff'][:10]} → {manifest['last_cutoff'][:10]} · Seed {manifest['config']['seed']} · {manifest['post_rows']:,} synthetic posts"
)

predictions = bundle["predictions"]
p = predictions[
    (predictions.model == model) & (predictions.horizon == horizon)
].sort_values("timestamp")
m = bundle["ml_metrics"].query("model == @model and horizon == @horizon").iloc[0]
bt = bundle["backtest_results"].query("model == @model and horizon == @horizon")
trading = (
    bundle["trading_metrics"].query("model == @model and horizon == @horizon").iloc[0]
)

if section == "Overview":
    latest = features.tail(24)
    cols = st.columns(4)
    cols[0].metric("Last synthetic close", f"${features.close.iloc[-1]:,.0f}")
    cols[1].metric("X sentiment · last 24h", f"{latest.sentiment_mean.mean():+.3f}")
    cols[2].metric("OOS origins", f"{int(m.predictions):,}")
    cols[3].metric("Walk-forward folds", str(int(m.folds)))
    st.subheader("Discussion meets market movement")
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    fig.add_trace(
        go.Scatter(
            x=features.timestamp,
            y=features.close,
            name="Synthetic close",
            line=dict(color=COLORS[1]),
        ),
        secondary_y=False,
    )
    fig.add_trace(
        go.Scatter(
            x=features.timestamp,
            y=features.sentiment_mean.rolling(24).mean(),
            name="24h X sentiment",
            line=dict(color=COLORS[0]),
        ),
        secondary_y=True,
    )
    fig.update_yaxes(title_text="Price / USD", secondary_y=False)
    fig.update_yaxes(title_text="Sentiment score", secondary_y=True)
    chart(fig)
    left, right = st.columns([1.5, 1])
    with left:
        st.subheader("Conversation volume")
        daily = (
            features.set_index("timestamp").post_count.resample("D").sum().reset_index()
        )
        chart(
            px.bar(
                daily,
                x="timestamp",
                y="post_count",
                labels={"post_count": "Synthetic posts", "timestamp": "UTC date"},
                color_discrete_sequence=[COLORS[0]],
            )
        )
    with right:
        st.subheader("Sentiment mix · last 24h")
        counts = [
            (latest[label + "_ratio"] * latest.post_count).sum()
            for label in ["positive", "neutral", "negative"]
        ]
        fig = go.Figure(
            go.Pie(
                labels=["Positive", "Neutral", "Negative"],
                values=counts,
                hole=0.7,
                marker=dict(colors=[COLORS[0], COLORS[1], "#F18D9E"]),
            )
        )
        chart(fig)
    st.info(
        "Read the baseline first: persistence has lower RMSE than both learned models in this synthetic run. High price-level R² alone does not establish predictive value."
    )

elif section == "Forecast explorer":
    st.subheader(f"{MODEL_NAMES[model]} · n+{horizon} / {horizon+1}-hour forecast")
    cols = st.columns(4)
    for col, label, value in zip(
        cols,
        ["RMSE / USD", "MAE / USD", "Directional accuracy", "R²"],
        [
            f"{m.RMSE:,.2f}",
            f"{m.MAE:,.2f}",
            f"{m.directional_accuracy:.1%}",
            f"{m.R2:.3f}",
        ],
    ):
        col.metric(label, value)
    period = st.slider(
        "Show last OOS origins",
        min_value=24,
        max_value=len(p),
        value=min(168, len(p)),
        step=12,
    )
    shown = p.tail(period)
    chart(
        px.line(
            shown,
            x="target_timestamp",
            y=["actual", "predicted"],
            labels={
                "value": "Price / USD",
                "target_timestamp": "Target cutoff / UTC",
                "variable": "Series",
            },
            color_discrete_sequence=[COLORS[1], COLORS[0]],
        )
    )
    left, right = st.columns(2)
    with left:
        scatter = p.assign(
            actual_return=p.actual / p.close - 1,
            predicted_return=p.predicted / p.close - 1,
        )
        chart(
            px.scatter(
                scatter,
                x="actual_return",
                y="predicted_return",
                labels={
                    "actual_return": "Actual forward return",
                    "predicted_return": "Predicted forward return",
                },
                opacity=0.65,
                color_discrete_sequence=[COLORS[0]],
            )
        )
    with right:
        st.markdown("#### Forecast ledger")
        st.caption(
            "Historical out-of-sample predictions; these are not current trade signals."
        )
        st.dataframe(
            shown[
                ["timestamp", "target_timestamp", "actual", "predicted", "fold"]
            ].tail(15),
            hide_index=True,
            width="stretch",
        )
    st.download_button(
        "Download selected forecasts",
        p.to_csv(index=False),
        "demo_forecasts.csv",
        "text/csv",
    )

elif section == "Strategy lab":
    st.subheader("What remains after trading costs?")
    st.caption(
        "Long / flat · next-bar open entry · non-overlapping holdings · no leverage"
    )
    cols = st.columns(4)
    for col, label, key, percent in zip(
        cols,
        ["Total return", "Sharpe ratio", "Maximum drawdown", "Win rate"],
        ["total_return", "sharpe", "max_drawdown", "win_rate"],
        [True, False, True, True],
    ):
        col.metric(label, metric_value(trading[key], percent))
    curves = equity_curves(bt)
    chart(
        px.line(
            curves,
            x="timestamp",
            y=["Strategy", "Buy & hold"],
            labels={
                "value": "Growth of $1",
                "timestamp": "Origin / UTC",
                "variable": "Portfolio",
            },
            color_discrete_sequence=COLORS,
        )
    )
    chart(
        px.area(
            curves,
            x="timestamp",
            y="Drawdown",
            labels={"Drawdown": "Drawdown", "timestamp": "Origin / UTC"},
            color_discrete_sequence=["#F18D9E"],
        )
    )
    st.caption(
        "One-way transaction fee 0.10% + slippage 0.02%; both entry and exit charged on every long trade. Buy & hold is gross over matching holding windows. Annualization: 8,760 / holding hours; undefined ratios are shown as Undefined."
    )
    st.dataframe(
        bundle["trading_metrics"].query("model == @model"),
        hide_index=True,
        width="stretch",
    )
    st.download_button(
        "Download strategy ledger",
        bt.to_csv(index=False),
        "demo_strategy.csv",
        "text/csv",
    )

elif section == "Model comparison":
    st.subheader("Can sentiment beat a simple baseline?")
    all_metrics = bundle["ml_metrics"].copy()
    all_metrics["Model"] = all_metrics.model.map(MODEL_NAMES)
    measure = st.selectbox(
        "Compare metric", ["RMSE", "MAE", "directional_accuracy", "R2"]
    )
    chart(
        px.line(
            all_metrics,
            x="horizon",
            y=measure,
            color="Model",
            markers=True,
            labels={"horizon": "Horizon n+"},
            color_discrete_sequence=COLORS,
        )
    )
    st.dataframe(
        all_metrics[
            [
                "Model",
                "horizon",
                "MAE",
                "RMSE",
                "R2",
                "directional_accuracy",
                "predictions",
                "folds",
            ]
        ],
        hide_index=True,
        width="stretch",
    )
    st.caption(
        "Models and parameters were fixed in advance. No best model is selected automatically from test results. Persistence predicts no change, so sign-match directional accuracy is zero when actual returns are nonzero."
    )
    st.download_button(
        "Download all ML metrics",
        all_metrics.to_csv(index=False),
        "demo_model_metrics.csv",
        "text/csv",
    )

else:
    st.subheader("Built for inspection, not promises")
    a, b = st.columns(2)
    with a:
        st.markdown(
            """#### Allowed model inputs
- Historical price and volume
- X post sentiment and causal lags
- Engagement aggregates (demo only)

#### Forecast clock
Information cutoff: completed bar close **t**. Posts in **(t−1h, t]** are available. **n+0 = t+1h**, through **n+5 = t+6h**. News and Exa context never enter model inputs."""
        )
    with b:
        st.markdown(
            """#### Out-of-sample protocol
Expanding chronological folds start at 60%, test 24 hours at a time, and purge six training origins. Every training label precedes the first test origin. Linear scaling is fitted inside each fold.

#### Limits
Synthetic data demonstrates implementation only. Real historical engagement is disabled to avoid future totals. Incomplete/deleted/edited posts and execution latency remain research limitations."""
        )
    st.dataframe(bundle["folds"], hide_index=True, width="stretch")
    st.markdown("#### Presentation downloads")
    st.download_button(
        "Download evaluation report",
        (SNAPSHOT / "evaluation_report.md").read_text(encoding="utf-8"),
        "demo_evaluation_report.md",
        "text/markdown",
    )
    st.download_button(
        "Download reproducibility manifest",
        (SNAPSHOT / "run_manifest.json").read_text(),
        "demo_manifest.json",
        "application/json",
    )
    st.caption(
        "The report references the chart files in reports/figures/ in the repository. No API keys or private raw posts are included in this dashboard."
    )

st.divider()
st.caption(
    "SIGNAL / Research demo · X sentiment + price only · Reproducible seed 42 · Synthetic data throughout"
)
