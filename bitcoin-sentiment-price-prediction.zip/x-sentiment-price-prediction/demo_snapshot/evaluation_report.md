# X sentiment multi-horizon price prediction

## 1. Executive Summary

DEMO — SYNTHETIC DATA; NOT REAL MARKET PERFORMANCE. All metrics below were computed by this run; no real-world profitability claim is made.

## 2. Objective

Predict six future closes from X sentiment and historical price information.

## 3. Dataset

{
  "demo": true,
  "asset": "BTC-USD",
  "created_utc": "2026-10-18T07:58:11.856546+00:00",
  "price_rows": 720,
  "post_rows": 1790,
  "news_rows": 1,
  "first_cutoff": "2026-01-01 00:00:00+00:00",
  "last_cutoff": "2026-01-30 23:00:00+00:00",
  "config": {
    "asset": "BTC-USD",
    "asset_name": "Bitcoin",
    "lookback_days": 180,
    "interval": "1h",
    "horizon_steps": 6,
    "seed": 42,
    "demo_bars": 720,
    "initial_train_fraction": 0.6,
    "test_window": 24,
    "step_size": 24,
    "transaction_cost": 0.001,
    "slippage": 0.0002,
    "signal_threshold": 0.0,
    "queries": [
      "Bitcoin",
      "BTC",
      "$BTC",
      "Bitcoin price",
      "BTCUSD"
    ],
    "apify_input_file": "config/apify_input.json",
    "apify_mapping_file": "config/apify_mapping.json",
    "model_params": {
      "max_iter": 70,
      "max_leaf_nodes": 15,
      "l2_regularization": 10
    },
    "apify_source": "local_exports",
    "minimum_x_hourly_coverage": 0.1,
    "demo": true
  },
  "python": "3.13.5",
  "versions": {
    "numpy": "2.3.5",
    "pandas": "2.3.3",
    "scikit-learn": "1.8.0",
    "matplotlib": "3.10.8",
    "requests": "2.34.2",
    "PyYAML": "6.0.2"
  }
}

## 4. Data Collection

Apify X, yfinance prices, Tavily news, optional Exa. DEMO replaces these with deterministic synthetic fixtures. Raw API responses are saved before normalization.

## 5. Data Cleaning

UTC normalization, post-ID deduplication, blank/invalid post rejection; invalid or missing hourly price bars fail explicitly. No price interpolation.

## 6. Sentiment Analysis

Real mode: ProsusAI/finbert, score=P(positive)-P(negative). DEMO uses an explicitly synthetic lexicon. Content/model hash cache. Engagement log weights capped at 1,000,000 per field. Real historical engagement/followers are zeroed because collection-time totals are not point-in-time observations.

## 7. Feature Engineering

Only explicit price and X feature allowlists. Trailing 24-hour statistics and sentiment lags. News and Exa remain separate. Empty sentiment buckets are zero with post_count=0.

## 8. Target Definition

Price timestamps are bar CLOSE cutoffs t. Posts in (t-1h,t] are usable. n+0 = close(t+1h), ..., n+5 = close(t+6h). Current close is known at t. Targets never appear in model inputs.

## 9. Model Architecture

Separate persistence, standardized LinearRegression and HistGradientBoostingRegressor models per horizon. Models learn forward returns and convert them to prices. Tree hyperparameters fixed in advance; no test-based selection.

## 10. Walk-Forward Validation

Expanding windows; final six origin rows purged from each training window so every training target is strictly before first test origin. Scalers fitted within each fold. No shuffled split. Fold boundaries in reports/folds.csv.

## 11. ML Performance

| model | horizon | MAE | RMSE | R2 | directional_accuracy | predictions | folds |
|---|---|---|---|---|---|---|---|
| linear | 0 | 144.118 | 180.729 | 0.978965 | 0.481884 | 276 | 12 |
| linear | 1 | 208.649 | 263.746 | 0.955925 | 0.518116 | 276 | 12 |
| linear | 2 | 255.576 | 320.936 | 0.935975 | 0.48913 | 276 | 12 |
| linear | 3 | 295.794 | 372.617 | 0.915156 | 0.507246 | 276 | 12 |
| linear | 4 | 341.246 | 422.449 | 0.892805 | 0.496377 | 276 | 12 |
| linear | 5 | 377.044 | 463.434 | 0.873321 | 0.514493 | 276 | 12 |
| persistence | 0 | 139.734 | 175.997 | 0.980052 | 0 | 276 | 12 |
| persistence | 1 | 197.911 | 253.898 | 0.959155 | 0 | 276 | 12 |
| persistence | 2 | 240.371 | 308.26 | 0.940933 | 0 | 276 | 12 |
| persistence | 3 | 276.77 | 356.201 | 0.922467 | 0 | 276 | 12 |
| persistence | 4 | 317.337 | 401.532 | 0.903158 | 0 | 276 | 12 |
| persistence | 5 | 352.609 | 441.337 | 0.885114 | 0 | 276 | 12 |
| tree | 0 | 144.493 | 181.789 | 0.978718 | 0.51087 | 276 | 12 |
| tree | 1 | 217.158 | 273.626 | 0.95256 | 0.496377 | 276 | 12 |
| tree | 2 | 270.762 | 338.383 | 0.928825 | 0.474638 | 276 | 12 |
| tree | 3 | 315.708 | 399.746 | 0.902352 | 0.503623 | 276 | 12 |
| tree | 4 | 373.517 | 456.812 | 0.874657 | 0.452899 | 276 | 12 |
| tree | 5 | 420.782 | 508.722 | 0.847353 | 0.456522 | 276 | 12 |

## 12. Trading Strategy

Long/flat forecast threshold 0.0. Fill next bar open, exit target close. Independent, non-overlapping 1–6-hour trades; each long trade pays entry and exit. One-way fee 0.10%, slippage 0.02%. No leverage. Close-to-open jumps excluded from held returns.

## 13. Sharpe Ratio

Mean net period return / sample standard deviation × sqrt(8760 / holding hours). Risk-free rate zero. Undefined denominators reported blank/undefined.

## 14. Sortino Ratio

Mean net period return / root mean square of all negative-part returns × sqrt(8760 / holding hours). Minimum acceptable return zero.

## 15. Maximum Drawdown

Minimum equity / running peak - 1, including initial equity=1. Measured at holding-period boundaries, so intratrade drawdowns may be larger.

## 16. Other Trading Metrics

| model | horizon | periods | long_trades | sharpe | sortino | max_drawdown | total_return | annualized_return | volatility | win_rate | buy_hold_total_return |
|---|---|---|---|---|---|---|---|---|---|---|---|
| linear | 0 | 276 | 175 | -54.3235 | -48.9749 | -0.36444 | -0.36444 | -0.999999 | 0.263957 | 0.171429 | -0.0481275 |
| linear | 1 | 138 | 89 | -32.1652 | -30.7501 | -0.190908 | -0.190078 | -0.998758 | 0.207201 | 0.258427 | -0.0481275 |
| linear | 2 | 92 | 58 | -19.6132 | -20.2362 | -0.143289 | -0.130707 | -0.988273 | 0.225221 | 0.293103 | -0.0481275 |
| linear | 3 | 69 | 46 | -14.9325 | -16.7258 | -0.113861 | -0.0949051 | -0.957781 | 0.210331 | 0.326087 | -0.0481275 |
| linear | 4 | 56 | 38 | -14.6035 | -15.9482 | -0.106964 | -0.100795 | -0.963989 | 0.22568 | 0.342105 | -0.0550828 |
| linear | 5 | 46 | 34 | -14.612 | -15.7008 | -0.11055 | -0.0902735 | -0.950356 | 0.203903 | 0.294118 | -0.0481275 |
| persistence | 0 | 276 | 0 | undefined | undefined | 0 | 0 | 0 | 0 | undefined | -0.0481275 |
| persistence | 1 | 138 | 0 | undefined | undefined | 0 | 0 | 0 | 0 | undefined | -0.0481275 |
| persistence | 2 | 92 | 0 | undefined | undefined | 0 | 0 | 0 | 0 | undefined | -0.0481275 |
| persistence | 3 | 69 | 0 | undefined | undefined | 0 | 0 | 0 | 0 | undefined | -0.0481275 |
| persistence | 4 | 56 | 0 | undefined | undefined | 0 | 0 | 0 | 0 | undefined | -0.0550828 |
| persistence | 5 | 46 | 0 | undefined | undefined | 0 | 0 | 0 | 0 | undefined | -0.0481275 |
| tree | 0 | 276 | 153 | -47.155 | -44.1964 | -0.310242 | -0.310242 | -0.999992 | 0.249166 | 0.183007 | -0.0481275 |
| tree | 1 | 138 | 77 | -31.215 | -29.991 | -0.181004 | -0.179539 | -0.998128 | 0.200427 | 0.246753 | -0.0481275 |
| tree | 2 | 92 | 54 | -21.3538 | -21.6685 | -0.138142 | -0.130586 | -0.988221 | 0.20684 | 0.259259 | -0.0481275 |
| tree | 3 | 69 | 43 | -17.9859 | -18.9833 | -0.107925 | -0.097754 | -0.961801 | 0.180499 | 0.27907 | -0.0481275 |
| tree | 4 | 56 | 31 | -19.0292 | -18.701 | -0.131337 | -0.12755 | -0.986003 | 0.222777 | 0.258065 | -0.0550828 |
| tree | 5 | 46 | 27 | -15.3601 | -15.2671 | -0.0802369 | -0.0754734 | -0.917146 | 0.161183 | 0.296296 | -0.0481275 |

## 17. Visualization

![sentiment_price.png](figures/sentiment_price.png)

![sentiment_trend.png](figures/sentiment_trend.png)

![post_volume.png](figures/post_volume.png)

![actual_predicted_n0.png](figures/actual_predicted_n0.png)

![actual_predicted_n1.png](figures/actual_predicted_n1.png)

![actual_predicted_n2.png](figures/actual_predicted_n2.png)

![actual_predicted_n3.png](figures/actual_predicted_n3.png)

![actual_predicted_n4.png](figures/actual_predicted_n4.png)

![actual_predicted_n5.png](figures/actual_predicted_n5.png)

![returns_scatter.png](figures/returns_scatter.png)

![equity.png](figures/equity.png)

![drawdown.png](figures/drawdown.png)

![heatmap.png](figures/heatmap.png)

![horizon_comparison.png](figures/horizon_comparison.png)

## 18. Current Sentiment Outlook

# Current X sentiment outlook

**DEMO — SYNTHETIC DATA; NOT REAL MARKET PERFORMANCE**

As of dataset cutoff 2026-01-30 23:00:00+00:00 (not necessarily current wall-clock time).

Current X sentiment indicates negative discussion.
Last 24 hourly buckets: mean score -0.0656; change from preceding 24 buckets -0.0438; posts 50.
Post-weighted mix: positive 32.0%, negative 32.0%, neutral 36.0%.
Trend: weakening. Missing-post hours have score zero; volume and sample coverage affect interpretation.
This describes sampled discussion and does not establish future price direction.

## Tavily context (excluded from all predictive features)

- DEMO synthetic context (not real news) (2026-01-30T23:00:00+00:00) — 

## Optional Exa context

Not configured / no supplementary results.


## 19. Limitations

Synthetic results verify software only. Real API paths require user credentials and Actor-specific mapping; no paid API call was performed in demo. Historical post sampling may be incomplete, deleted/edited posts introduce survivorship/revision bias, and FinBERT is not crypto-specific. Historical engagement is disabled in real mode. FinBERT pretraining dates may overlap evaluation history. Backtest execution at next open approximates latency; historical OHLCV is not a live order book. No claim of fully audited point-in-time live data. Provider missing bars fail for manual investigation. No hyperparameter search or uncertainty estimates.

## 20. Conclusion

Compare all fixed models with persistence across horizons. Reported performance is descriptive OOS evaluation, not a guarantee or an automatically selected trading recommendation.

## 21. Reproducibility Instructions

See README.md; python scripts/run_pipeline.py executes stages 1–6. Run pytest before changing data/model settings. reports/run_manifest.json records configuration, data counts and package versions.