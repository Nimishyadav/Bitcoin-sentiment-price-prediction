# Current X sentiment outlook

**DEMO — SYNTHETIC DATA; NOT REAL MARKET PERFORMANCE**

As of dataset cutoff 2026-01-30 23:00:00+00:00 (not necessarily current wall-clock time).

Current X sentiment indicates negative discussion.
Last 24 hourly buckets: mean score -0.0656; change from preceding 24 buckets -0.0438; posts 50.
Post-weighted mix: positive 32.0%, negative 32.0%, neutral 36.0%.
Trend: weakening. Missing-post hours have score zero; volume and sample coverage affect interpretation.
This describes sampled discussion and does not establish future price direction.

## Tavily context (excluded from all predictive features)

- DEMO synthetic context (not real news) (2026-01-30T23:00:00+00:00) — 

## Optional Exa context

Not configured / no supplementary results.
