import pandas as pd
import pytest
from src.ingestion.apify_x import normalize_posts
from src.ingestion.price_loader import validate_prices
from src.ingestion.demo import generate
from src.config import load_config


def test_timestamp_duplicate_malformed():
    good = {"id": "1", "createdAt": "2026-01-01T05:30:00+05:30", "text": "BTC"}
    df = normalize_posts(
        [
            good,
            good,
            {"id": "2", "createdAt": "bad", "text": "x"},
            {"id": "3", "createdAt": good["createdAt"], "text": " "},
        ]
    )
    assert len(df) == 1
    assert df.timestamp.iloc[0] == pd.Timestamp("2026-01-01", tz="UTC")
    assert df.likes.iloc[0] == 0


def test_missing_price_bar_rejected():
    prices, _, _ = generate(load_config())
    with pytest.raises(ValueError, match="Missing"):
        validate_prices(prices.drop(index=30))


def test_invalid_price_rejected():
    prices, _, _ = generate(load_config())
    prices.loc[4, "close"] = -1
    with pytest.raises(ValueError, match="Invalid"):
        validate_prices(prices)
