import numpy as np
import pandas as pd
from src.config import load_config
from src.ingestion.demo import generate
from src.sentiment.finbert import aggregate, score_probabilities
from src.features.feature_engineering import build, FEATURE_COLUMNS, TARGET_COLUMNS


def fixture():
    prices, posts, _ = generate(load_config())
    posts["sentiment_score"] = np.linspace(-1, 1, len(posts))
    posts["label"] = "neutral"
    return prices, posts


def test_score():
    assert np.isclose(score_probabilities(0.8, 0.1), 0.7)


def test_cutoff_boundary():
    prices, posts = fixture()
    t = prices.timestamp.iloc[50]
    posts = posts.iloc[:2].copy()
    posts["timestamp"] = [t, t + pd.Timedelta(seconds=1)]
    a = aggregate(posts, prices.timestamp)
    assert a.loc[a.timestamp == t, "post_count"].iloc[0] == 1
    assert a.loc[a.timestamp == t + pd.Timedelta(hours=1), "post_count"].iloc[0] == 1


def test_targets_and_feature_allowlist():
    prices, posts = fixture()
    f = build(prices, aggregate(posts, prices.timestamp))
    assert len(TARGET_COLUMNS) == 6
    origin = f.iloc[0]
    idx = prices.index[prices.timestamp == origin.timestamp][0]
    for h in range(6):
        assert origin[f"target_n{h}"] == prices.close.iloc[idx + h + 1]
    assert set(TARGET_COLUMNS).isdisjoint(FEATURE_COLUMNS)
    assert not any("news" in x for x in FEATURE_COLUMNS)


def test_future_mutation_does_not_change_features():
    prices, posts = fixture()
    cutoff = prices.timestamp.iloc[200]
    first = build(prices, aggregate(posts, prices.timestamp))
    mutated = prices.copy()
    mutated.loc[mutated.timestamp > cutoff, ["open", "high", "low", "close"]] *= 2
    posts2 = posts.copy()
    posts2.loc[posts2.timestamp > cutoff, "sentiment_score"] = 100
    second = build(mutated, aggregate(posts2, prices.timestamp))
    pd.testing.assert_frame_equal(
        first.loc[first.timestamp <= cutoff, FEATURE_COLUMNS],
        second.loc[second.timestamp <= cutoff, FEATURE_COLUMNS],
    )


def test_engagement_cap_and_no_post_bucket():
    prices, posts = fixture()
    posts = posts.iloc[:2].copy()
    posts["views"] = 1e30
    a = aggregate(posts, prices.timestamp)
    assert a.weighted_sentiment_mean.abs().max() <= 1
    assert (a.post_count == 0).any()
