import pytest
from src.ingestion import http
from src.ingestion.apify_x import normalize_posts


class Response:
    def __init__(self, status, payload):
        self.status_code = status
        self.ok = 200 <= status < 300
        self.headers = {}
        self.payload = payload

    def json(self):
        return self.payload


def test_rate_limit_retry(monkeypatch):
    responses = iter([Response(429, {}), Response(200, {"ok": True})])
    monkeypatch.setattr(http.requests, "request", lambda *a, **k: next(responses))
    monkeypatch.setattr(http.time, "sleep", lambda x: None)
    assert http.request("GET", "https://example.invalid") == {"ok": True}


def test_credential_failure_redacts_body(monkeypatch):
    monkeypatch.setattr(
        http.requests,
        "request",
        lambda *a, **k: Response(401, {"secret": "do-not-echo"}),
    )
    with pytest.raises(RuntimeError, match="HTTP 401") as e:
        http.request("GET", "https://example.invalid")
    assert "do-not-echo" not in str(e.value)


def test_custom_actor_mapping():
    df = normalize_posts(
        [{"record": {"key": "a", "date": "2026-01-01", "body": "BTC"}}],
        {"post_id": "record.key", "timestamp": "record.date", "text": "record.body"},
    )
    assert len(df) == 1 and df.post_id.iloc[0] == "a"
