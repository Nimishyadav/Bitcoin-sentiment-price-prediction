from pathlib import Path
import pytest
from src.dashboard import load_snapshot, equity_curves


def test_synthetic_snapshot_consistency():
    b = load_snapshot()
    assert b["manifest"]["demo"] is True
    assert len(b["prices"]) == b["manifest"]["price_rows"]
    assert set(b["predictions"].horizon) == set(range(6))
    assert len(b["ml_metrics"]) == 18
    p = b["predictions"]
    assert not p.duplicated(["timestamp", "horizon", "model"]).any()
    assert (
        len(
            equity_curves(
                b["backtest_results"].query('model == "tree" and horizon == 0')
            )
        )
        > 0
    )


def test_dashboard_views_and_filters():
    from streamlit.testing.v1 import AppTest

    root = Path(__file__).resolve().parents[1]
    app = AppTest.from_file(str(root / "app.py"), default_timeout=30).run()
    assert not app.exception
    assert len(app.metric) == 4
    for section in [
        "Forecast explorer",
        "Strategy lab",
        "Model comparison",
        "Methodology & report",
    ]:
        app.radio[0].set_value(section).run()
        assert not app.exception
    app.radio[0].set_value("Forecast explorer").run()
    app.selectbox[0].set_value("persistence")
    app.select_slider[0].set_value(5).run()
    assert not app.exception
    assert any("SYNTHETIC" in w.value.upper() for w in app.warning)
