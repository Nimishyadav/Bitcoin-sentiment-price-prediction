import json
import pandas as pd
import pytest
from src.ingestion.history import make_plan, import_exports
from src.ingestion import history
from src.ingestion.apify_x import collect


def test_daily_plan_boundaries():
    plan = make_plan(180, "2026-10-18")
    assert len(plan) == 180
    assert plan[-1]["end_utc"] == "2026-10-18T00:00:00+00:00"
    for a, b in zip(plan, plan[1:]):
        assert a["end_utc"] == b["start_utc"]
    assert "since:2026-10-17 until:2026-10-18" in plan[-1]["query"]


def test_import_filters_future_and_reports_missing_days(tmp_path, monkeypatch):
    monkeypatch.setattr(history, "ROOT", tmp_path)
    directory = tmp_path / "data/raw/history/exports"
    directory.mkdir(parents=True)
    records = [
        {"id": "1", "date": "2026-10-17T12:00:00Z", "body": "Bitcoin"},
        {"id": "future", "date": "2026-10-18T12:00:00Z", "body": "BTC"},
    ]
    (directory / "posts.json").write_text(json.dumps(records))
    posts, coverage = import_exports(
        directory,
        {"post_id": "id", "timestamp": "date", "text": "body"},
        make_plan(2, "2026-10-18"),
    )
    assert len(posts) == 1
    assert coverage["days_with_posts"] == 1
    assert coverage["complete_daily_coverage"] is False
    assert coverage["missing_dates"] == ["2026-10-16"]


def test_paid_actor_disabled(monkeypatch):
    monkeypatch.delenv("ALLOW_BILLABLE_APIFY", raising=False)
    with pytest.raises(ValueError, match="disabled"):
        collect({"apify_source": "api"})
