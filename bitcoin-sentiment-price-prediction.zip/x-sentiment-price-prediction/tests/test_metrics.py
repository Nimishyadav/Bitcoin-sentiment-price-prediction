import numpy as np
import pandas as pd
from src.evaluation.backtest import trading_metrics, backtest
from src.models.walk_forward import splits


def test_risk_metrics():
    r = np.array([0.1, -0.1, 0.05, -0.02])
    m = trading_metrics(r, 8760)
    assert np.isclose(m["sharpe"], r.mean() / r.std(ddof=1) * np.sqrt(8760))
    assert np.isclose(
        m["sortino"], r.mean() / np.sqrt(np.mean(np.minimum(r, 0) ** 2)) * np.sqrt(8760)
    )
    assert np.isclose(m["max_drawdown"], -0.1)
    assert np.isclose(m["total_return"], np.prod(1 + r) - 1)


def test_initial_loss_drawdown():
    assert np.isclose(trading_metrics([-0.2, 0.1], 8760)["max_drawdown"], -0.2)


def test_undefined_ratios():
    m = trading_metrics([0, 0], 8760)
    assert m["sharpe"] is None and m["sortino"] is None


def test_walk_forward_purge_and_unique_coverage():
    folds = list(splits(200, 0.6, 24, 24))
    seen = []
    for tr, te in folds:
        assert max(tr) + 6 < min(te)
        assert max(tr) < min(te)
        seen.extend(te)
    assert seen == list(range(120, 200))


def test_execution_cost_and_nonoverlap():
    times = pd.date_range("2026-01-01", periods=12, freq="h", tz="UTC")
    prices = pd.DataFrame({"timestamp": times, "open": 100.0, "close": 100.0})
    p = pd.DataFrame(
        {
            "timestamp": times[:8],
            "target_timestamp": times[2:10],
            "model": "tree",
            "horizon": 1,
            "close": 100.0,
            "predicted": 101.0,
        }
    )
    records, summary = backtest(
        p, prices, {"transaction_cost": 0.001, "slippage": 0, "signal_threshold": 0}
    )
    assert len(records) == 4
    assert np.allclose(records.strategy_return, 0.999 / 1.001 - 1)
    assert summary.long_trades.iloc[0] == 4
