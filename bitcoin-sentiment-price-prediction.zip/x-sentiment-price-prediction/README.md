# Signal — X sentiment × Bitcoin price research

**Free Streamlit dashboard • Six forecast horizons • Walk-forward evaluation**

![Dashboard preview](reports/dashboard_preview.png)

Present the complete project without API keys or paid requests:

```powershell
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

The public dashboard uses the measured **synthetic demo snapshot**, labels it on every view, and never opens private `.env` or raw real posts. Explore overview, forecast explorer, strategy lab, model comparison and methodology/report downloads. Root dependencies are lightweight; install `requirements-real.txt` only for real price/FinBERT ingestion. The free workflow disables automatic Apify Actor launches.

**[GitHub upload and free Streamlit deployment guide →](DEPLOYMENT.md)**

A ready-to-upload source ZIP can be generated with `python scripts/check_release.py --zip`. It excludes credentials, raw posts, SQLite and environments. The local ZIP is `dist/x-sentiment-github.zip`. GitHub/public hosting has not been created yet.

**Real-data status:** the provided 20 X posts verified Actor mapping only. A separate free Yahoo price download has an hourly gap and is rejected for modeling. Full 180-day X history and real-data model results remain unavailable. The offline date-window planner/importer reports coverage instead of relabeling incomplete samples as complete history.

---

# X (Twitter) sentiment-based multi-horizon asset price prediction

A runnable research pipeline for Bitcoin hourly closes, using only X sentiment and price-derived predictive features. Tavily news and optional Exa results are report context only. **The checked-in evaluation is DEMO / synthetic, not real market performance.** No credentials were supplied and no paid ingestion was run.

## Quick start (PowerShell, Python 3.11–3.13)

Obtain this project by cloning your own repository URL (`git clone <your-repository-url>`) or copying this folder. No remote repository was created by this assignment.

```powershell
cd 'C:\Users\Nimish yadav\Downloads\job'
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
# For real FinBERT/yfinance support: install requirements-real.txt
Copy-Item .env.example .env
$env:DEMO_MODE='true'
$env:OMP_NUM_THREADS='2'
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe scripts/run_pipeline.py
```

`OMP_NUM_THREADS` bounds native tree-model parallelism. Environment variables override `.env`; change/remove the PowerShell `DEMO_MODE` variable before switching modes. Each run's generated tables replace prior tables: archive wanted outputs **inside this project** before recollecting. Run stages sequentially.

The delivered local `.venv` reuses already installed scientific dependencies and contains pytest; a fresh environment should install `requirements.txt`. `requirements-demo-lock.txt` records exact versions used for this demo. Transformer/PyTorch/yfinance are lazy real-mode imports and are not required for the demo itself.

## Pipeline commands

```powershell
.\.venv\Scripts\python.exe scripts/01_collect_data.py
.\.venv\Scripts\python.exe scripts/02_process_sentiment.py
.\.venv\Scripts\python.exe scripts/03_build_features.py
.\.venv\Scripts\python.exe scripts/04_train_models.py
.\.venv\Scripts\python.exe scripts/05_evaluate.py
.\.venv\Scripts\python.exe scripts/06_generate_report.py
```

The convenience `scripts/run_pipeline.py` runs all six. Stage provenance guards reject changed mode, asset, or configuration after collection. Rerun all stages after configuration changes. Data directories, logs, SQLite and caches stay inside this project; source paths resolve independently of the shell's working directory.

## Architecture and complete structure

```text
job/
  README.md, requirements.txt, requirements-demo-lock.txt, .env.example, .gitignore
  config/
    config.yaml, apify_mapping.example.json, apify_input.template.txt
  src/
    config.py, pipeline.py
    ingestion/ apify_x.py, price_loader.py, tavily_news.py, exa_search.py, demo.py, http.py
    database/ db.py
    sentiment/ finbert.py
    features/ feature_engineering.py
    models/ train.py, walk_forward.py
    evaluation/ metrics.py, backtest.py
    visualization/ charts.py
    reporting/ report_generator.py
  scripts/ 01_collect_data.py ... 06_generate_report.py, run_pipeline.py, validate_outputs.py
  tests/ conftest.py, test_api.py, test_ingestion.py, test_features.py, test_metrics.py
  data/ raw/, processed/, database/market.db, cache/
  logs/ pipeline.log
  reports/
    evaluation_report.md, current_sentiment_outlook.md
    ml_metrics.csv, fold_metrics.csv, trading_metrics.csv, folds.csv
    run_manifest.json, validation.json, assignment_checklist.md, files_created.txt
    figures/ (14 PNGs)
```

All source/config/documentation files are new: the initial folder was empty. `reports/files_created.txt` inventories delivery files, excluding environment/cache internals.

## Real APIs and configuration

Edit `.env` locally:

```dotenv
DEMO_MODE=false
APIFY_API_TOKEN=
APIFY_ACTOR_ID=
TAVILY_API_KEY=
EXA_API_KEY=
ASSET_SYMBOL=BTC-USD
ASSET_NAME=Bitcoin
```

Fill the Apify token/Actor ID and Tavily key. Exa is optional. Never paste secrets into source, config YAML, commands, reports or issue descriptions. `.env` is ignored. No real credential values are provided here.

1. Select an X Actor in Apify and inspect **that Actor's input schema, pricing, and example output** in its console. No Actor is assumed compatible automatically.
2. Adapt `config/apify_input.template.txt` to its actual input fields, save as `config/apify_input.json`. Optional substitutions: `{{QUERIES_JSON}}` inserts the configured query array (without surrounding quotes); `{{START_UTC}}` and `{{END_UTC}}` insert UTC date strings. If the Actor expects dates or query strings in another format, supply its exact input manually. The template is deliberately not a runnable Actor payload.
3. Copy `config/apify_mapping.example.json` to `config/apify_mapping.json` and adapt every dotted field path to actual output. An unavailable optional field can map to a nonexistent path. ID/time/text must exist. No executable code is loaded from mapping files.
4. Set `APIFY_ACTOR_ID` in `.env`. Run collection. Raw paginated items are saved to `data/raw/apify.jsonl`; `apify_schema.json` lists observed top-level keys. If normalization fails, inspect raw output locally and correct the adapter. Never publish author/private data inadvertently.
5. Follow DEPLOYMENT.md to import sufficient historical exports before setting `$env:DEMO_MODE='false'`. The free workflow never launches an Actor automatically. The Actor launch is not retried automatically, preventing duplicate billable jobs; failed/timeout launches require checking the Apify console before restarting. Polling/reads and context searches retry bounded transient failures and 429 responses.

Tavily searches latest/market/ETF/regulation news from the past week; missing publication dates remain unknown. Exa executes one supplementary context search when configured. These are current context and may postdate historical evaluation; they never enter training. Calls use HTTPS, timeouts and sanitized error messages.

Official API contracts consulted: [Apify REST run/dataset flow](https://docs.apify.com/academy/api/run-actor-and-retrieve-data-via-api), [Tavily search](https://docs.tavily.com/documentation/api-reference/endpoint/search), [Exa search](https://exa.ai/docs/reference/search), [FinBERT model card](https://huggingface.co/ProsusAI/finbert), [yfinance download](https://ranaroussi.github.io/yfinance/reference/api/yfinance.download.html).

`config/config.yaml` controls asset, 180-day requested lookback, queries, training fraction, test window, step size, tree parameters, fees, slippage, threshold and seed. The validated frequency is **1h**, with **six horizons**; other values fail explicitly instead of silently using wrong annualization. Other tickers may have exchange closures or limited hourly availability; this BTC-focused implementation requires contiguous hourly data. Provider history limits can prevent the full requested 180 days; inspect manifest coverage. No bar is interpolated.

## Data schema and cleaning

SQLite tables: `x_posts` (normalized ID/text/author/UTC timestamp/engagement/query); `prices` (close-cutoff timestamp/OHLCV); `news` (title/URL/source/publication date/content/query); `sentiment_posts` (post fields/probabilities/score/label/model); `sentiment_hourly` (bucket aggregates); `features` (causal features + six target columns); `predictions` (origin/target timestamps/model/horizon/fold/actual/forecast); `backtest_results` (signal, holding-period return, comparator).

Every timestamped table has a timestamp index. Dynamic SQL identifiers are restricted to a static table allowlist; pandas' SQLite writer parameterizes values. Null/malformed/blank posts are discarded with counts logged; IDs deduplicated. Timestamps normalize to UTC. Missing/invalid OHLCV bars fail rather than conceal gaps. UTC sorting and duplicate-bar removal occur before modeling.

## Timestamp convention and leakage controls

Provider OHLCV timestamps are bar **opening** times; ingestion shifts these by one hour to store completed-bar **closing cutoff t**. Incomplete bars are dropped. Posts in `(t-1h,t]` aggregate at `t`. At an exact cutoff, a post belongs to that cutoff. No later post is included. Empty buckets have zeros and `post_count=0`, which distinguishes missing discussion from observed neutral discussion.

At cutoff t, all price features use bars closed by t. `target_n0 = close(t+1h)`, ... `target_n5 = close(t+6h)`. n+0 is **not** the already known current close. Targets are held outside the explicit feature allowlist. Trailing return/volatility windows use 24 hours; lags use previous rows on a validated complete grid. Last six rows retain unknown targets for inspection but are excluded from OOS evaluation.

Historical post engagement totals and followers fetched today contain future information. Real mode therefore zeros them for historical modeling (original snapshots remain in raw files); demo exercises engagement handling. If point-in-time engagement becomes available, add a verified availability-time adapter before enabling it. Text publication-time availability is assumed; deleted/edited posts and incomplete historical search remain unavoidable sampling caveats.

Real sentiment uses Hugging Face `ProsusAI/finbert`; positive-minus-negative probabilities give a score in [-1,1]. Model/content hashes cache scores. Real model-loading failures stop sentiment with an actionable message and never silently substitute the demo lexicon. Engagement weighting is `1 + sum(log1p(min(count, 1e6)))` over likes/reposts/views; hourly normalization divides weights by their bucket sum. Followers are summarized separately and never used to amplify weights. Fixed caps avoid learning future distribution quantiles.

## Models and walk-forward validation

Each horizon fits separate standardized LinearRegression and HistGradientBoostingRegressor models, plus persistence `forecast=current close`. Models learn forward fractional returns and convert predictions to prices. HistGradientBoosting is the supported stronger tree model; XGBoost is not required. Train-only standardization is inside each fold's sklearn pipeline. No tuned parameters are selected using the test set.

Default expanding window starts at 60% and tests the next 24 hours, then advances 24. A six-origin purge ensures `last_train_origin + 6h < first_test_origin`. Every test origin appears once; `step_size` must equal `test_window`. Fold boundaries and fold-level metrics are persisted. These are evaluation fits, not a serialized live-serving deployment. Model artifacts can be added after defining a production serving contract.

## Evaluation and backtest

MAE/RMSE in quote-currency price units, R², exact sign-match directional accuracy, prediction counts, and fold counts are reported by model/horizon. Persistence predicts zero return, so its directional accuracy is zero when actual returns are nonzero; it abstains in trading. High price-level R² alone is not evidence of return predictability.

Signals use forecast/current close - 1 > threshold (default 0) to enter long; otherwise flat. Execution fills the **next bar's open**, exits at target close, with one independent strategy per model/horizon. The strategy waits until its horizon finishes before taking another signal; future overlapping predictions are not stacked. By default each long trade closes and reopens independently even when consecutive signals remain long, paying both sides. One-way transaction fee is **0.10%** and one-way slippage **0.02%**. No borrowing, leverage or short exposure. Comparator returns are gross buy-and-hold over corresponding sampled holding windows.

Annualization for 24/7 hourly BTC: `8760 / holding_hours` observations/year. Sharpe uses sample standard deviation and zero risk-free rate; Sortino uses RMS negative-part returns including zero contributions from positive periods, with zero minimum acceptable return. Drawdown includes initial equity 1. Annualized geometric return extrapolates observed periods; short demo extrapolations are not reliable forecasts. Win rate is among nonzero net-return periods. Undefined ratios remain null/blank. Drawdowns within individual holding periods are not measured.

## Measured demo results

The deterministic seed-42 demonstration generated 720 hourly bars, 1,790 posts, 696 feature rows, 12 folds, and 276 OOS origins per model/horizon (4,968 predictions across 18 model/horizon pairs). It is deliberately not engineered to make sentiment predictive.

For n+0: persistence RMSE **175.9971**, linear **180.7290**, tree **181.7886** USD. Tree directional accuracy **51.09%**; tree strategy total return **-31.02%** after costs. These are **synthetic software-validation results only**. The stronger model does not beat persistence in this run. All six horizons and trading metrics are in `reports/evaluation_report.md` and CSVs.

## Outputs, tests, limitations and security

- `reports/evaluation_report.md`: generated 21-part evaluation with charts and all model/horizon results.
- `reports/current_sentiment_outlook.md`: concise dataset-cutoff outlook with news/Exa context.
- `reports/figures/`: sentiment/price, trend, volume, six actual/forecast plots, return scatter, equity, drawdown, heatmap, horizon comparison.
- `reports/run_manifest.json`: mode, UTC coverage, counts, public configuration, seed and measured package versions.
- `reports/assignment_checklist.md`: requirement-by-requirement delivery and manual configuration status.
- `python -m pytest -q`: ingestion, schema adapters, HTTP retry/redaction, cutoff alignment, score, target, future-mutation invariance, engagement caps, purge, costs and risk metrics.
- `python scripts/validate_outputs.py`: checks generated SQLite tables, six targets, OOS boundaries, prediction coverage, metrics and 14 figures; writes `reports/validation.json`.

Raw datasets, SQLite, caches, logs, .env and virtual environments are ignored. Do not upload raw X data without reviewing privacy/licensing. No credentials are logged in request errors. All generated metrics derive from run outputs. Missing API credentials are not a reason to manufacture real results. No real APIs/FinBERT weights were tested in this delivery; user-provided credentials, selected Actor contract and model download are still required.

Limitations: no audited point-in-time post archive, exchange execution engine, confidence intervals, hyperparameter search, corporate-action calendar or live model service. The system is a tested research project, not a profitability guarantee. Future improvements: archive timestamped live snapshots, benchmark sentiment against price-only ablations, calibrated uncertainty, stability studies and an independently audited execution simulator.
