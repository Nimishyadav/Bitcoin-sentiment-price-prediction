"""Read-only dashboard data access. Public demo never reads .env or local real data."""

import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SNAPSHOT = ROOT / "demo_snapshot"


def load_snapshot():
    manifest = json.loads((SNAPSHOT / "run_manifest.json").read_text())
    if manifest.get("demo") is not True:
        raise ValueError(
            "Public dashboard accepts only an explicitly synthetic snapshot"
        )
    result = {"manifest": manifest}
    for name in [
        "prices",
        "features",
        "predictions",
        "backtest_results",
        "ml_metrics",
        "trading_metrics",
        "folds",
    ]:
        df = pd.read_csv(SNAPSHOT / (name + ".csv"))
        for column in ["timestamp", "target_timestamp", "exit_timestamp"]:
            if column in df:
                df[column] = pd.to_datetime(df[column], utc=True)
        result[name] = df
    return result


def equity_curves(records):
    frame = records.sort_values("timestamp").copy()
    frame["Strategy"] = (1 + frame["strategy_return"]).cumprod()
    frame["Buy & hold"] = (1 + frame["buy_hold_return"]).cumprod()
    peaks = np.maximum.accumulate(np.r_[1.0, frame["Strategy"]])[1:]
    frame["Drawdown"] = frame["Strategy"] / peaks - 1
    return frame
