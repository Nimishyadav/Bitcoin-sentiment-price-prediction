"""Causal price/sentiment-only features and explicitly forward-shifted targets."""

import numpy as np
import pandas as pd

PRICE_FEATURES = [
    "close",
    "volume",
    "price_change",
    "rolling_return",
    "rolling_volatility",
] + [f"log_return_{k}" for k in [1, 3, 6, 12, 24]]
SENTIMENT_FEATURES = [
    "sentiment_mean",
    "sentiment_std",
    "weighted_sentiment_mean",
    "positive_ratio",
    "negative_ratio",
    "neutral_ratio",
    "post_count",
    "total_likes",
    "total_reposts",
    "total_views",
    "average_author_followers",
] + [f"sentiment_lag_{k}" for k in [1, 2, 3]]
FEATURE_COLUMNS = PRICE_FEATURES + SENTIMENT_FEATURES
TARGET_COLUMNS = [f"target_n{h}" for h in range(6)]


def build(prices, sentiment):
    df = (
        prices.merge(sentiment, on="timestamp", how="left", validate="one_to_one")
        .sort_values("timestamp")
        .reset_index(drop=True)
    )
    for col in SENTIMENT_FEATURES[:11]:
        df[col] = df[col].fillna(0)
    for k in [1, 3, 6, 12, 24]:
        df[f"log_return_{k}"] = np.log(df["close"] / df["close"].shift(k))
    df["price_change"] = df["close"].pct_change(fill_method=None)
    df["rolling_return"] = df["log_return_1"].rolling(24).sum()
    df["rolling_volatility"] = df["log_return_1"].rolling(24).std()
    for k in [1, 2, 3]:
        df[f"sentiment_lag_{k}"] = df["sentiment_mean"].shift(k)
    for h in range(6):
        df[f"target_n{h}"] = df["close"].shift(-(h + 1))
    df = df.replace([np.inf, -np.inf], np.nan).dropna(subset=FEATURE_COLUMNS)
    if len(df) < 100:
        raise ValueError(
            "Insufficient history: need at least 100 feature rows after 24-hour warmup"
        )
    return df.reset_index(drop=True)
