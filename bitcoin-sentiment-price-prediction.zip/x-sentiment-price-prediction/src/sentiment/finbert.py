"""FinBERT scoring with content/model-aware disk cache; explicit demo-only lexicon."""

import hashlib
import json
import numpy as np
import pandas as pd
from src.config import ROOT


def score_probabilities(positive, negative):
    return positive - negative


def score(posts, demo=False):
    model_id = "demo-lexicon-v1" if demo else "ProsusAI/finbert"
    cache_path = ROOT / "data/processed/sentiment_cache.json"
    cache = json.loads(cache_path.read_text()) if cache_path.exists() else {}
    keys = [
        hashlib.sha256((model_id + "|" + str(x)).encode()).hexdigest()
        for x in posts["text"]
    ]
    missing = {k: t for k, t in zip(keys, posts["text"]) if k not in cache}
    if demo:
        for k, t in missing.items():
            cache[k] = (
                [0.8, 0.1, 0.1]
                if "bullish" in t
                else ([0.1, 0.8, 0.1] if "bearish" in t else [0.1, 0.1, 0.8])
            )
    elif missing:
        try:
            from transformers import pipeline

            classifier = pipeline(
                "text-classification", model=model_id, tokenizer=model_id, device=-1
            )
            entries = list(missing.items())
            for start in range(0, len(entries), 32):
                batch = entries[start : start + 32]
                results = classifier(
                    [x[1] for x in batch], truncation=True, max_length=512, top_k=None
                )
                for (k, _), result in zip(batch, results):
                    probs = {x["label"].lower(): x["score"] for x in result}
                    cache[k] = [probs["positive"], probs["negative"], probs["neutral"]]
        except Exception:
            raise RuntimeError(
                "FinBERT failed to load/score; install torch/transformers and enable model download. No silent lexicon fallback in real mode."
            ) from None
    cache_path.write_text(json.dumps(cache))
    result = posts.copy()
    result[["positive_probability", "negative_probability", "neutral_probability"]] = (
        np.array([cache[k] for k in keys])
    )
    result["sentiment_score"] = score_probabilities(
        result["positive_probability"], result["negative_probability"]
    )
    result["label"] = np.array(["positive", "negative", "neutral"])[
        result[["positive_probability", "negative_probability", "neutral_probability"]]
        .to_numpy()
        .argmax(axis=1)
    ]
    result["sentiment_model"] = model_id
    return result


def aggregate(posts, cutoffs):
    p = posts.copy()
    # Fixed caps are ex ante constants, not quantiles learned from all data.
    p["engagement_weight"] = 1 + sum(
        np.log1p(p[col].clip(0, 1_000_000)) for col in ["likes", "reposts", "views"]
    )
    p["timestamp"] = p["timestamp"].dt.ceil("h")
    rows = []
    for timestamp, g in p.groupby("timestamp"):
        w = g["engagement_weight"]
        rows.append(
            {
                "timestamp": timestamp,
                "sentiment_mean": g["sentiment_score"].mean(),
                "sentiment_std": g["sentiment_score"].std(ddof=0),
                "weighted_sentiment_mean": np.average(g["sentiment_score"], weights=w),
                **{
                    label + "_ratio": g["label"].eq(label).mean()
                    for label in ["positive", "negative", "neutral"]
                },
                "post_count": len(g),
                "total_likes": g["likes"].sum(),
                "total_reposts": g["reposts"].sum(),
                "total_views": g["views"].sum(),
                "average_author_followers": g["followers"].mean(),
            }
        )
    if not rows:
        raise ValueError("No sentiment posts to aggregate")
    hourly = (
        pd.DataFrame(rows)
        .set_index("timestamp")
        .reindex(pd.DatetimeIndex(cutoffs))
        .fillna(0)
    )
    hourly.index.name = "timestamp"
    return hourly.reset_index()
