"""Expanding chronological validation with six-bar label purge."""


def splits(n, fraction=0.6, test_window=24, step_size=24, purge=6):
    if step_size != test_window:
        raise ValueError("step_size must equal test_window")
    initial = int(n * fraction)
    if initial - purge < 30 or initial >= n:
        raise ValueError("Insufficient training/test observations")
    for start in range(initial, n, step_size):
        # Last train origin + max horizon < first test origin.
        yield range(0, start - purge), range(start, min(start + test_window, n))
