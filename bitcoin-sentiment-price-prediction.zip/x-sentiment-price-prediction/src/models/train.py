"""Independent models per horizon, return targets improve stationarity."""

import logging
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from src.features.feature_engineering import FEATURE_COLUMNS, TARGET_COLUMNS
from src.models.walk_forward import splits


def train(features, c):
    df = features.dropna(subset=TARGET_COLUMNS).reset_index(drop=True)
    rows = []
    folds = []
    for fold, (training, testing) in enumerate(
        splits(len(df), c["initial_train_fraction"], c["test_window"], c["step_size"])
    ):
        tr, te = df.iloc[list(training)], df.iloc[list(testing)]
        folds.append(
            {
                "fold": fold,
                "train_start": str(tr.timestamp.iloc[0]),
                "train_end": str(tr.timestamp.iloc[-1]),
                "last_train_label": str(tr.timestamp.iloc[-1] + pd.Timedelta(hours=6)),
                "test_start": str(te.timestamp.iloc[0]),
                "test_end": str(te.timestamp.iloc[-1]),
                "train_rows": len(tr),
                "test_rows": len(te),
            }
        )
        for h in range(6):
            y = tr[f"target_n{h}"] / tr["close"] - 1
            models = {
                "linear": make_pipeline(StandardScaler(), LinearRegression()),
                "tree": HistGradientBoostingRegressor(
                    random_state=c["seed"], **c["model_params"]
                ),
            }
            forecasts = {"persistence": te["close"].to_numpy()}
            for name, model in models.items():
                model.fit(tr[FEATURE_COLUMNS], y)
                forecasts[name] = te["close"].to_numpy() * (
                    1 + model.predict(te[FEATURE_COLUMNS])
                )
            for name, predicted in forecasts.items():
                for (_, r), pred in zip(te.iterrows(), predicted):
                    rows.append(
                        {
                            "timestamp": r.timestamp,
                            "target_timestamp": r.timestamp + pd.Timedelta(hours=h + 1),
                            "fold": fold,
                            "model": name,
                            "horizon": h,
                            "close": r["close"],
                            "actual": r[f"target_n{h}"],
                            "predicted": float(pred),
                        }
                    )
        logging.info("Completed fold %s: %s train / %s test", fold, len(tr), len(te))
    if not rows:
        raise ValueError("No out-of-sample predictions generated")
    return pd.DataFrame(rows), pd.DataFrame(folds)
