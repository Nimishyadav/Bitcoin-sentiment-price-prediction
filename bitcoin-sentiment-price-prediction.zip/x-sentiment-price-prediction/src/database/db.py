"""SQLite persistence with explicit table allowlists and parameterized values."""

import sqlite3
import pandas as pd
from src.config import ROOT

TABLES = {
    "x_posts",
    "prices",
    "news",
    "sentiment_posts",
    "sentiment_hourly",
    "features",
    "predictions",
    "backtest_results",
}


def connect():
    db = sqlite3.connect(ROOT / "data/database/market.db")
    db.execute("PRAGMA journal_mode=WAL")
    return db


def save(name, frame):
    if name not in TABLES:
        raise ValueError("Unknown table")
    data = frame.copy()
    for col in data:
        if isinstance(data[col].dtype, pd.DatetimeTZDtype):
            data[col] = data[col].astype(str)
    with connect() as db:
        data.to_sql(name, db, if_exists="replace", index=False)
        if "timestamp" in data:
            # Identifiers are restricted to the static allowlist above.
            db.execute(
                "CREATE INDEX IF NOT EXISTS idx_"
                + name
                + "_timestamp ON "
                + name
                + "(timestamp)"
            )


def read(name):
    if name not in TABLES:
        raise ValueError("Unknown table")
    with connect() as db:
        df = pd.read_sql_query("SELECT * FROM " + name, db)
    for col in ["timestamp", "target_timestamp"]:
        if col in df:
            df[col] = pd.to_datetime(df[col], utc=True)
    return df
