"""Reports generated exclusively from persisted, measured pipeline outputs."""

import json
import pandas as pd
from src.config import ROOT


def table(df):
    # Avoid an otherwise unused tabulate dependency.
    df = df.copy()
    for col in df.select_dtypes("number"):
        df[col] = df[col].map(lambda v: f"{v:.6g}" if pd.notna(v) else "undefined")
    return (
        "| "
        + " | ".join(df.columns)
        + " |\n|"
        + "|".join(["---"] * len(df.columns))
        + "|\n"
        + "\n".join(
            "| " + " | ".join(map(str, row)) + " |"
            for row in df.itertuples(index=False, name=None)
        )
    )


def generate(c, features, metrics, trading, news, figures, manifest):
    mode = (
        "DEMO — SYNTHETIC DATA; NOT REAL MARKET PERFORMANCE"
        if c["demo"]
        else "REAL API DATA — HISTORICAL OUT-OF-SAMPLE EVALUATION"
    )
    recent = features.tail(24)
    previous = features.iloc[-48:-24]
    count = recent.post_count.sum()
    ratios = {
        label: (
            float((recent[label + "_ratio"] * recent.post_count).sum() / count)
            if count
            else 0
        )
        for label in ["positive", "negative", "neutral"]
    }
    score = float(recent.sentiment_mean.mean())
    change = score - float(previous.sentiment_mean.mean())
    outlook = f"""# Current X sentiment outlook\n\n**{mode}**\n\nAs of dataset cutoff {features.timestamp.iloc[-1]} (not necessarily current wall-clock time).\n\nCurrent X sentiment indicates {'positive' if score>0.05 else 'negative' if score<-.05 else 'neutral/mixed'} discussion.\nLast 24 hourly buckets: mean score {score:.4f}; change from preceding 24 buckets {change:+.4f}; posts {count:.0f}.\nPost-weighted mix: positive {ratios['positive']:.1%}, negative {ratios['negative']:.1%}, neutral {ratios['neutral']:.1%}.\nTrend: {'improving' if change>0 else 'weakening'}. Missing-post hours have score zero; volume and sample coverage affect interpretation.\nThis describes sampled discussion and does not establish future price direction.\n\n## Tavily context (excluded from all predictive features)\n\n"""
    for _, r in news.head(6).iterrows():
        outlook += f'- {r.title} ({r.publication_date or "publication date unavailable"}) — {r.url}\n'
    exa_path = ROOT / "data/raw/exa_context.json"
    exa = json.loads(exa_path.read_text()) if exa_path.exists() else {"results": []}
    outlook += "\n## Optional Exa context\n\n"
    for x in exa.get("results", []):
        outlook += f'- {x.get("title","")} — {x.get("url","")}\n'
    if not exa.get("results"):
        outlook += "Not configured / no supplementary results.\n"
    (ROOT / "reports/current_sentiment_outlook.md").write_text(
        outlook, encoding="utf-8"
    )
    sections = [
        (
            "Executive Summary",
            mode
            + ". All metrics below were computed by this run; no real-world profitability claim is made.",
        ),
        (
            "Objective",
            "Predict six future closes from X sentiment and historical price information.",
        ),
        ("Dataset", json.dumps(manifest, indent=2)),
        (
            "Data Collection",
            "Apify X, yfinance prices, Tavily news, optional Exa. DEMO replaces these with deterministic synthetic fixtures. Raw API responses are saved before normalization.",
        ),
        (
            "Data Cleaning",
            "UTC normalization, post-ID deduplication, blank/invalid post rejection; invalid or missing hourly price bars fail explicitly. No price interpolation.",
        ),
        (
            "Sentiment Analysis",
            "Real mode: ProsusAI/finbert, score=P(positive)-P(negative). DEMO uses an explicitly synthetic lexicon. Content/model hash cache. Engagement log weights capped at 1,000,000 per field. Real historical engagement/followers are zeroed because collection-time totals are not point-in-time observations.",
        ),
        (
            "Feature Engineering",
            "Only explicit price and X feature allowlists. Trailing 24-hour statistics and sentiment lags. News and Exa remain separate. Empty sentiment buckets are zero with post_count=0.",
        ),
        (
            "Target Definition",
            "Price timestamps are bar CLOSE cutoffs t. Posts in (t-1h,t] are usable. n+0 = close(t+1h), ..., n+5 = close(t+6h). Current close is known at t. Targets never appear in model inputs.",
        ),
        (
            "Model Architecture",
            "Separate persistence, standardized LinearRegression and HistGradientBoostingRegressor models per horizon. Models learn forward returns and convert them to prices. Tree hyperparameters fixed in advance; no test-based selection.",
        ),
        (
            "Walk-Forward Validation",
            "Expanding windows; final six origin rows purged from each training window so every training target is strictly before first test origin. Scalers fitted within each fold. No shuffled split. Fold boundaries in reports/folds.csv.",
        ),
        ("ML Performance", table(metrics)),
        (
            "Trading Strategy",
            f'Long/flat forecast threshold {c["signal_threshold"]}. Fill next bar open, exit target close. Independent, non-overlapping {1}–6-hour trades; each long trade pays entry and exit. One-way fee {c["transaction_cost"]:.2%}, slippage {c["slippage"]:.2%}. No leverage. Close-to-open jumps excluded from held returns.',
        ),
        (
            "Sharpe Ratio",
            "Mean net period return / sample standard deviation × sqrt(8760 / holding hours). Risk-free rate zero. Undefined denominators reported blank/undefined.",
        ),
        (
            "Sortino Ratio",
            "Mean net period return / root mean square of all negative-part returns × sqrt(8760 / holding hours). Minimum acceptable return zero.",
        ),
        (
            "Maximum Drawdown",
            "Minimum equity / running peak - 1, including initial equity=1. Measured at holding-period boundaries, so intratrade drawdowns may be larger.",
        ),
        ("Other Trading Metrics", table(trading)),
        ("Visualization", "\n\n".join(f"![{x}](figures/{x})" for x in figures)),
        ("Current Sentiment Outlook", outlook),
        (
            "Limitations",
            "Synthetic results verify software only. Real API paths require user credentials and Actor-specific mapping; no paid API call was performed in demo. Historical post sampling may be incomplete, deleted/edited posts introduce survivorship/revision bias, and FinBERT is not crypto-specific. Historical engagement is disabled in real mode. FinBERT pretraining dates may overlap evaluation history. Backtest execution at next open approximates latency; historical OHLCV is not a live order book. No claim of fully audited point-in-time live data. Provider missing bars fail for manual investigation. No hyperparameter search or uncertainty estimates.",
        ),
        (
            "Conclusion",
            "Compare all fixed models with persistence across horizons. Reported performance is descriptive OOS evaluation, not a guarantee or an automatically selected trading recommendation.",
        ),
        (
            "Reproducibility Instructions",
            "See README.md; python scripts/run_pipeline.py executes stages 1–6. Run pytest before changing data/model settings. reports/run_manifest.json records configuration, data counts and package versions.",
        ),
    ]
    text = "# X sentiment multi-horizon price prediction\n\n" + "\n\n".join(
        f"## {i}. {title}\n\n{body}" for i, (title, body) in enumerate(sections, 1)
    )
    (ROOT / "reports/evaluation_report.md").write_text(text, encoding="utf-8")
