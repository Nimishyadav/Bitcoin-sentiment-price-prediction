"""Restartable pipeline stages with provenance guards against mixed-mode artifacts."""

import importlib.metadata
import json
import logging
import platform
from datetime import datetime, timezone
import pandas as pd
from src.config import ROOT, load_config
from src.database.db import read, save


def manifest(c):
    path = ROOT / "data/processed/manifest.json"
    if not path.exists():
        raise ValueError("Run data collection first")
    m = json.loads(path.read_text())
    if m["demo"] != c["demo"] or m["asset"] != c["asset"]:
        raise ValueError(
            "Artifact provenance differs from current mode/asset. Re-run all stages."
        )
    return m


def stage(number):
    c = load_config()
    if number == 1:
        if c["demo"]:
            from src.ingestion.demo import generate

            prices, posts, news = generate(c)
            (ROOT / "data/raw/exa_context.json").write_text(
                json.dumps({"results": [], "status": "DEMO"})
            )
            for name, df in [("prices", prices), ("x_posts", posts), ("news", news)]:
                df.to_json(
                    ROOT / f"data/raw/demo_{name}.json",
                    orient="records",
                    date_format="iso",
                )
        else:
            from src.ingestion import apify_x, price_loader, tavily_news, exa_search

            prices = price_loader.collect(c)
            posts = apify_x.collect(c)
            news = tavily_news.collect(c)
            exa_search.collect(c)
            # Do not leak future engagement totals into historical bars.
            posts[["likes", "reposts", "views", "followers"]] = 0
        posts = posts[
            (posts.timestamp > prices.timestamp.min() - pd.Timedelta(hours=1))
            & (posts.timestamp <= prices.timestamp.max())
        ]
        if posts.empty:
            raise ValueError("No X posts overlap the price observation window")
        for name, df in [("prices", prices), ("x_posts", posts), ("news", news)]:
            save(name, df)
        m = {
            "demo": c["demo"],
            "asset": c["asset"],
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "price_rows": len(prices),
            "post_rows": len(posts),
            "news_rows": len(news),
            "first_cutoff": str(prices.timestamp.min()),
            "last_cutoff": str(prices.timestamp.max()),
            "config": c,
            "python": platform.python_version(),
            "versions": {
                p: importlib.metadata.version(p)
                for p in [
                    "numpy",
                    "pandas",
                    "scikit-learn",
                    "matplotlib",
                    "requests",
                    "PyYAML",
                ]
            },
        }
        (ROOT / "data/processed/manifest.json").write_text(json.dumps(m, indent=2))
        # Invalidate downstream tables so old results cannot masquerade as a new run.
        from src.database.db import connect

        with connect() as db:
            for name in [
                "sentiment_posts",
                "sentiment_hourly",
                "features",
                "predictions",
                "backtest_results",
            ]:
                db.execute("DROP TABLE IF EXISTS " + name)
    else:
        m = manifest(c)
        if m["config"] != c:
            raise ValueError(
                "Configuration changed after collection; rerun all stages to preserve provenance"
            )
        if number == 2:
            from src.sentiment.finbert import score, aggregate

            scored = score(read("x_posts"), c["demo"])
            save("sentiment_posts", scored)
            save("sentiment_hourly", aggregate(scored, read("prices").timestamp))
        elif number == 3:
            from src.features.feature_engineering import build

            features = build(read("prices"), read("sentiment_hourly"))
            save("features", features)
            features.to_csv(ROOT / "data/processed/features.csv", index=False)
        elif number == 4:
            from src.models.train import train

            predictions, folds = train(read("features"), c)
            save("predictions", predictions)
            folds.to_csv(ROOT / "reports/folds.csv", index=False)
        elif number == 5:
            from src.evaluation.metrics import evaluate
            from src.evaluation.backtest import backtest

            predictions = read("predictions")
            metrics = evaluate(predictions)
            metrics.to_csv(ROOT / "reports/ml_metrics.csv", index=False)
            fold_metrics = pd.concat(
                [
                    evaluate(group).assign(fold=fold)
                    for fold, group in predictions.groupby("fold")
                ],
                ignore_index=True,
            )
            fold_metrics.to_csv(ROOT / "reports/fold_metrics.csv", index=False)
            records, summary = backtest(predictions, read("prices"), c)
            save("backtest_results", records)
            summary.to_csv(ROOT / "reports/trading_metrics.csv", index=False)
        elif number == 6:
            from src.visualization.charts import generate
            from src.reporting.report_generator import generate as report

            features = read("features")
            metrics = pd.read_csv(ROOT / "reports/ml_metrics.csv")
            trading = pd.read_csv(ROOT / "reports/trading_metrics.csv")
            figures = generate(
                features,
                read("predictions"),
                read("backtest_results"),
                metrics,
                c["demo"],
            )
            report(c, features, metrics, trading, read("news"), figures, m)
            (ROOT / "reports/run_manifest.json").write_text(json.dumps(m, indent=2))
        else:
            raise ValueError("Stage must be 1–6")
    logging.info("Stage %s completed (%s)", number, "DEMO" if c["demo"] else "REAL")
