"""OHLCV ingestion. Provider timestamps denote opening times; store close cutoffs."""

import logging
import numpy as np
import pandas as pd
from src.config import ROOT


def validate_prices(df):
    df = df.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
    df = (
        df.dropna(subset=["timestamp"])
        .drop_duplicates("timestamp")
        .sort_values("timestamp")
    )
    cols = ["open", "high", "low", "close", "volume"]
    df[cols] = df[cols].apply(pd.to_numeric, errors="coerce")
    valid = np.isfinite(df[cols]).all(axis=1) & (
        df[["open", "high", "low", "close"]] > 0
    ).all(axis=1)
    valid &= (
        (df["volume"] >= 0)
        & (df["high"] >= df[["open", "close", "low"]].max(axis=1))
        & (df["low"] <= df[["open", "close", "high"]].min(axis=1))
    )
    if not valid.all():
        raise ValueError(
            "Invalid OHLCV bars; repair the data source rather than silently filling prices"
        )
    if df.empty or not df["timestamp"].diff().dropna().eq(pd.Timedelta(hours=1)).all():
        raise ValueError(
            "Missing/non-hourly price bars; no synthetic interpolation permitted"
        )
    return df.reset_index(drop=True)


def collect(c):
    import yfinance as yf

    yf.set_tz_cache_location(str(ROOT / "data/cache/yfinance"))

    df = yf.download(
        c["asset"],
        period=f'{c["lookback_days"]}d',
        interval=c["interval"],
        auto_adjust=False,
        progress=False,
    )
    if df.empty:
        raise ValueError("Price provider returned no data")
    df.to_csv(ROOT / "data/raw/prices_provider.csv")
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    df = df.rename(columns=str.lower).rename_axis("timestamp").reset_index()
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True) + pd.Timedelta(hours=1)
    df = df[df["timestamp"] <= pd.Timestamp.now(tz="UTC")]
    result = validate_prices(
        df[["timestamp", "open", "high", "low", "close", "volume"]]
    )
    logging.info("Loaded %s completed price bars", len(result))
    return result
