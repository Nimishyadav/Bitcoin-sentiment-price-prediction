"""Tavily context only; never imported by feature construction."""

import json
import os
from urllib.parse import urlparse
import pandas as pd
from src.config import ROOT
from src.ingestion.http import request

COLUMNS = ["title", "url", "source", "publication_date", "content", "query"]


def collect(c):
    key = os.getenv("TAVILY_API_KEY")
    if not key:
        raise ValueError("Real mode requires TAVILY_API_KEY for required news context")
    rows = []
    for suffix in ["latest news", "market news", "ETF news", "regulation news"]:
        query = c["asset_name"] + " " + suffix
        data = request(
            "POST",
            "https://api.tavily.com/search",
            headers={"Authorization": f"Bearer {key}"},
            json={
                "query": query,
                "topic": "news",
                "max_results": 5,
                "time_range": "week",
                "include_published_date": True,
            },
        )
        (ROOT / f'data/raw/tavily_{suffix.replace(" ","_")}.json').write_text(
            json.dumps(data), encoding="utf-8"
        )
        for x in data.get("results", []):
            rows.append(
                dict(
                    title=x.get("title", ""),
                    url=x.get("url", ""),
                    source=urlparse(x.get("url", "")).netloc,
                    publication_date=x.get("published_date"),
                    content=x.get("content", ""),
                    query=query,
                )
            )
    result = pd.DataFrame(rows, columns=COLUMNS).drop_duplicates("url")
    result["publication_date"] = pd.to_datetime(
        result["publication_date"], utc=True, errors="coerce", format="mixed"
    )
    return result
