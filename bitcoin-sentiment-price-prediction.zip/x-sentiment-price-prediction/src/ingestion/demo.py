"""Deterministic synthetic fixtures; no simulated values are represented as live data."""

import numpy as np
import pandas as pd
from src.ingestion.apify_x import normalize_posts
from src.ingestion.price_loader import validate_prices
from src.ingestion.tavily_news import COLUMNS


def generate(c):
    rng = np.random.default_rng(c["seed"])
    times = pd.date_range("2026-01-01", periods=c["demo_bars"], freq="h", tz="UTC")
    close = 60000 * np.exp(np.cumsum(rng.normal(0, 0.003, len(times))))
    opening = np.r_[close[0], close[:-1]]
    prices = pd.DataFrame(
        {
            "timestamp": times,
            "open": opening,
            "high": np.maximum(opening, close) * 1.002,
            "low": np.minimum(opening, close) * 0.998,
            "close": close,
            "volume": rng.uniform(100, 1000, len(times)),
        }
    )
    items = []
    for i, t in enumerate(times):
        for j in range(int(rng.integers(1, 5))):
            word = rng.choice(["bullish growth", "bearish loss", "neutral market"])
            items.append(
                {
                    "id": f"{i}-{j}",
                    "createdAt": (
                        t - pd.Timedelta(minutes=int(rng.integers(1, 60)))
                    ).isoformat(),
                    "text": f"DEMO Bitcoin {word}",
                    "author": {
                        "id": f"a{j}",
                        "userName": f"demo{j}",
                        "followers": int(rng.integers(1, 10000)),
                    },
                    "likeCount": int(rng.integers(0, 200)),
                    "retweetCount": int(rng.integers(0, 50)),
                    "viewCount": int(rng.integers(0, 10000)),
                    "url": "",
                }
            )
    return (
        validate_prices(prices),
        normalize_posts(items, query="DEMO synthetic"),
        pd.DataFrame(
            [
                [
                    "DEMO synthetic context (not real news)",
                    "",
                    "demo",
                    times[-1].isoformat(),
                    "Synthetic demonstration only",
                    "DEMO",
                ]
            ],
            columns=COLUMNS,
        ),
    )
