"""Offline historical X planning/import. This module never starts an Apify run."""

import json
from pathlib import Path
import pandas as pd
from src.config import ROOT
from src.ingestion.apify_x import normalize_posts


def make_plan(days=180, end=None, max_posts=20):
    end = pd.Timestamp(end) if end else pd.Timestamp.now(tz="UTC").normalize()
    end = end.tz_localize("UTC") if end.tzinfo is None else end.tz_convert("UTC")
    end = end.normalize()
    if days < 1 or max_posts < 1:
        raise ValueError("days and max_posts must be positive")
    rows = []
    for day in pd.date_range(end - pd.Timedelta(days=days), periods=days, freq="D"):
        until = day + pd.Timedelta(days=1)
        rows.append(
            {
                "date": str(day.date()),
                "start_utc": day.isoformat(),
                "end_utc": until.isoformat(),
                "query": f"(Bitcoin OR BTC) lang:en since:{day.date()} until:{until.date()}",
                "search_type": "Latest",
                "max_posts": max_posts,
                "status": "not_collected",
            }
        )
    return rows


def import_exports(directory, mapping, plan):
    directory = Path(directory).resolve()
    allowed = (ROOT / "data/raw/history").resolve()
    if not directory.is_relative_to(allowed):
        raise ValueError("Historical exports must stay inside job/data/raw/history")
    files = sorted(directory.glob("*.json"))
    if not files:
        raise ValueError(
            "No local exports. Put downloaded Apify result JSON files in data/raw/history/exports. No paid run is launched automatically."
        )
    items = []
    for path in files:
        batch = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(batch, list):
            raise ValueError(f"{path.name} must contain an array of post objects")
        items.extend(batch)
    posts = normalize_posts(items, mapping, query="Local exported historical X results")
    start = pd.Timestamp(plan[0]["start_utc"])
    end = pd.Timestamp(plan[-1]["end_utc"])
    posts = posts[(posts.timestamp >= start) & (posts.timestamp < end)].copy()
    dates = set(posts.timestamp.dt.strftime("%Y-%m-%d"))
    hours = posts.timestamp.dt.floor("h").nunique()
    report = {
        "source": "REAL_LOCAL_EXPORTS",
        "expected_days": len(plan),
        "days_with_posts": len(dates),
        "posts_in_window": len(posts),
        "hours_with_posts": int(hours),
        "expected_hours": len(plan) * 24,
        "hourly_coverage": hours / (len(plan) * 24),
        "missing_dates": [r["date"] for r in plan if r["date"] not in dates],
        "complete_daily_coverage": len(dates) == len(plan),
        "note": "Sampled posts are not an exhaustive archive. Empty hours mean unavailable sampled discussion, not neutral observed discussion.",
    }
    return posts, report


def load_for_pipeline(c):
    plan = make_plan(c["lookback_days"])
    mapping = json.loads((ROOT / c["apify_mapping_file"]).read_text())
    posts, coverage = import_exports(ROOT / "data/raw/history/exports", mapping, plan)
    (ROOT / "reports/history_coverage.json").write_text(json.dumps(coverage, indent=2))
    if not coverage["complete_daily_coverage"]:
        raise ValueError(
            f"Historical exports cover {coverage['days_with_posts']}/{coverage['expected_days']} days. See reports/history_coverage.json. Refusing to label a partial sample as a complete historical run."
        )
    if coverage["hourly_coverage"] < c.get("minimum_x_hourly_coverage", 0.1):
        raise ValueError(
            "Historical X hourly coverage is below the configured minimum; see reports/history_coverage.json"
        )
    return posts
