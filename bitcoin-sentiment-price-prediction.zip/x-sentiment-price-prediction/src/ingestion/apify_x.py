"""Configurable dotted-path schema adapter and paginated Apify REST ingestion."""

import json
import logging
import os
import time
import pandas as pd
from src.config import ROOT
from src.ingestion.http import request

DEFAULT_MAPPING = {
    "post_id": "id",
    "timestamp": "createdAt",
    "text": "text",
    "author_id": "author.id",
    "username": "author.userName",
    "followers": "author.followers",
    "likes": "likeCount",
    "reposts": "retweetCount",
    "views": "viewCount",
    "url": "url",
}


def dotted(item, path):
    value = item
    for key in path.split("."):
        if not isinstance(value, dict):
            return None
        value = value.get(key)
    return value


def normalize_posts(items, mapping=None, query=""):
    mapping = mapping or DEFAULT_MAPPING
    rows = [
        {**{key: dotted(x, path) for key, path in mapping.items()}, "query": query}
        for x in items
        if isinstance(x, dict)
    ]
    df = pd.DataFrame(rows, columns=[*DEFAULT_MAPPING, "query"])
    df["timestamp"] = pd.to_datetime(
        df["timestamp"], utc=True, errors="coerce", format="mixed"
    )
    df["text"] = df["text"].fillna("").astype(str).str.strip()
    df = df.dropna(subset=["timestamp", "post_id"])
    df = df[df["text"].ne("") & df["post_id"].astype(str).ne("")].copy()
    df["post_id"] = df["post_id"].astype(str)
    for col in ["followers", "likes", "reposts", "views"]:
        df[col] = (
            pd.to_numeric(df[col], errors="coerce").fillna(0).clip(lower=0, upper=1e12)
        )
    df = df.drop_duplicates("post_id").sort_values("timestamp").reset_index(drop=True)
    logging.info("X schema adapter accepted %s of %s records", len(df), len(items))
    return df


def collect(c):
    if c.get("apify_source") == "local_exports":
        from src.ingestion.history import load_for_pipeline

        return load_for_pipeline(c)
    if os.getenv("ALLOW_BILLABLE_APIFY", "false").lower() != "true":
        raise ValueError(
            "Automatic Apify runs are disabled. Use local exports for the free workflow."
        )
    token, actor = os.getenv("APIFY_API_TOKEN"), os.getenv("APIFY_ACTOR_ID")
    if not token or not actor:
        raise ValueError(
            "Real mode requires APIFY_API_TOKEN and APIFY_ACTOR_ID in .env"
        )
    path = ROOT / c["apify_input_file"]
    mapping_path = ROOT / c["apify_mapping_file"]
    if not path.exists() or not mapping_path.exists():
        raise ValueError(
            "Create Actor input and mapping JSON from the selected Actor schema; see README"
        )
    payload_text = path.read_text().replace(
        "{{QUERIES_JSON}}", json.dumps(c["queries"])
    )
    payload_text = payload_text.replace(
        "{{START_UTC}}",
        (
            pd.Timestamp.now(tz="UTC") - pd.Timedelta(days=c["lookback_days"])
        ).isoformat(),
    )
    payload_text = payload_text.replace(
        "{{END_UTC}}", pd.Timestamp.now(tz="UTC").isoformat()
    )
    payload = json.loads(payload_text)
    mapping = json.loads(mapping_path.read_text())
    if not set(DEFAULT_MAPPING).issubset(mapping):
        raise ValueError(
            "Mapping must define every normalized field; missing fields may map to an absent path"
        )
    headers = {"Authorization": f"Bearer {token}"}
    base = "https://api.apify.com/v2"
    run = request(
        "POST",
        f'{base}/acts/{actor.replace("/","~")}/runs',
        headers=headers,
        json=payload,
        attempts=1,
    )["data"]
    deadline = time.monotonic() + 1800
    while run["status"] not in {"SUCCEEDED", "FAILED", "TIMED-OUT", "ABORTED"}:
        if time.monotonic() > deadline:
            raise RuntimeError(
                "Actor polling timed out; inspect the existing run before restarting to avoid duplicate charges"
            )
        time.sleep(5)
        run = request("GET", f'{base}/actor-runs/{run["id"]}', headers=headers)["data"]
    if run["status"] != "SUCCEEDED":
        raise RuntimeError("Apify Actor did not succeed: " + run["status"])
    items, offset = [], 0
    raw_path = ROOT / "data/raw/apify.jsonl"
    with raw_path.open("w", encoding="utf-8") as output:
        while True:
            page = request(
                "GET",
                f'{base}/datasets/{run["defaultDatasetId"]}/items',
                headers=headers,
                params={"offset": offset, "limit": 1000, "format": "json"},
            )
            for item in page:
                output.write(json.dumps(item, ensure_ascii=False) + "\n")
            items.extend(page)
            offset += len(page)
            if len(page) < 1000:
                break
    if not items:
        raise ValueError("Apify dataset is empty")
    (ROOT / "data/raw/apify_schema.json").write_text(
        json.dumps(
            {
                "top_level_keys": sorted(
                    set().union(*(x.keys() for x in items if isinstance(x, dict)))
                )
            },
            indent=2,
        )
    )
    result = normalize_posts(
        items, mapping, query="Actor input: " + c["apify_input_file"]
    )
    if result.empty:
        raise ValueError(
            "No usable posts. Inspect saved raw schema and adjust apify_mapping.json"
        )
    return result
