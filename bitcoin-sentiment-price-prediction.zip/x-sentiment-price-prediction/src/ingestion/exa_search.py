"""Optional Exa supplementary research, excluded from model inputs."""

import json
import os
from src.config import ROOT
from src.ingestion.http import request


def collect(c):
    key = os.getenv("EXA_API_KEY")
    data = {"results": [], "status": "EXA_API_KEY not configured"}
    if key:
        data = request(
            "POST",
            "https://api.exa.ai/search",
            headers={"x-api-key": key},
            json={
                "query": c["asset_name"] + " market context",
                "numResults": 5,
                "contents": {"text": True},
            },
        )
    (ROOT / "data/raw/exa_context.json").write_text(json.dumps(data), encoding="utf-8")
    return data
