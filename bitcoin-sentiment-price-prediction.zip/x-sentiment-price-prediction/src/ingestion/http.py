"""HTTP with bounded retries; never log response bodies or credentials."""

import time
import requests


def request(method, url, attempts=4, **kwargs):
    for attempt in range(attempts):
        try:
            response = requests.request(method, url, timeout=60, **kwargs)
        except requests.RequestException:
            if attempt == attempts - 1:
                raise RuntimeError(
                    "Network request failed; inspect service status before restarting"
                ) from None
            time.sleep(2**attempt)
            continue
        if response.status_code == 429 or response.status_code >= 500:
            if attempt < attempts - 1:
                delay = response.headers.get("Retry-After", "0")
                time.sleep(
                    min(60, max(2**attempt, float(delay) if delay.isdigit() else 0))
                )
                continue
        if not response.ok:
            raise RuntimeError(
                f"API returned HTTP {response.status_code}; check credentials and configuration"
            )
        return response.json()
    raise RuntimeError("API retry limit exceeded")
