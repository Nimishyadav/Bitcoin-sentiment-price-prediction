"""Out-of-sample regression and directional metrics."""

import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def evaluate(predictions):
    rows = []
    for (model, h), g in predictions.groupby(["model", "horizon"]):
        rows.append(
            {
                "model": model,
                "horizon": h,
                "MAE": mean_absolute_error(g.actual, g.predicted),
                "RMSE": np.sqrt(mean_squared_error(g.actual, g.predicted)),
                "R2": r2_score(g.actual, g.predicted),
                "directional_accuracy": np.mean(
                    np.sign(g.predicted - g.close) == np.sign(g.actual - g.close)
                ),
                "predictions": len(g),
                "folds": g.fold.nunique(),
            }
        )
    return pd.DataFrame(rows)
