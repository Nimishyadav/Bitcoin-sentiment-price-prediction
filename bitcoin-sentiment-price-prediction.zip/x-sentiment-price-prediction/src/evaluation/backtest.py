"""Non-overlapping long/flat trades. Signals at cutoff fill next bar open."""

import numpy as np
import pandas as pd


def trading_metrics(returns, periods_per_year):
    r = np.asarray(returns, dtype=float)
    equity = np.r_[1.0, np.cumprod(1 + r)]
    drawdown = equity / np.maximum.accumulate(equity) - 1
    std = np.std(r, ddof=1) if len(r) > 1 else 0
    downside = np.sqrt(np.mean(np.minimum(r, 0) ** 2))
    total = equity[-1] - 1
    return {
        "sharpe": (
            float(np.mean(r) / std * np.sqrt(periods_per_year)) if std > 0 else None
        ),
        "sortino": (
            float(np.mean(r) / downside * np.sqrt(periods_per_year))
            if downside > 0
            else None
        ),
        "max_drawdown": float(drawdown.min()),
        "total_return": float(total),
        "annualized_return": (
            float(np.expm1(np.log(equity[-1]) * periods_per_year / len(r)))
            if len(r) and equity[-1] > 0
            else None
        ),
        "volatility": float(std * np.sqrt(periods_per_year)),
        "win_rate": float(np.mean(r[r != 0] > 0)) if np.any(r != 0) else None,
    }


def backtest(predictions, prices, c):
    records = []
    summary = []
    indexed = prices.set_index("timestamp")
    for (model, h), g in predictions.groupby(["model", "horizon"]):
        g = g.sort_values("timestamp")
        next_free = None
        chunk = []
        for _, r in g.iterrows():
            if next_free is not None and r.timestamp < next_free:
                continue
            entry_time = r.timestamp + pd.Timedelta(hours=1)
            if (
                entry_time not in indexed.index
                or r.target_timestamp not in indexed.index
            ):
                continue
            entry = float(indexed.loc[entry_time, "open"])
            exit_price = float(indexed.loc[r.target_timestamp, "close"])
            signal = int(r.predicted / r["close"] - 1 > c["signal_threshold"])
            market_return = exit_price / entry - 1
            # Every trade closes at its horizon, so charge both sides for each long trade.
            cost = c["transaction_cost"] + c["slippage"]
            net = (1 + market_return) * (1 - cost) / (1 + cost) - 1
            item = {
                "timestamp": r.timestamp,
                "exit_timestamp": str(r.target_timestamp),
                "model": model,
                "horizon": h,
                "signal": signal,
                "strategy_return": signal * net,
                "buy_hold_return": market_return,
            }
            chunk.append(item)
            next_free = r.target_timestamp
        if not chunk:
            continue
        frame = pd.DataFrame(chunk)
        if not frame.timestamp.diff().dropna().eq(pd.Timedelta(hours=h + 1)).all():
            raise ValueError("Backtest requires contiguous OOS coverage")
        periods = 365 * 24 / (h + 1)
        summary.append(
            {
                "model": model,
                "horizon": h,
                "periods": len(frame),
                "long_trades": int(frame.signal.sum()),
                **trading_metrics(frame.strategy_return, periods),
                "buy_hold_total_return": float((1 + frame.buy_hold_return).prod() - 1),
            }
        )
        records.extend(chunk)
    return pd.DataFrame(records), pd.DataFrame(summary)
