"""Project configuration and paths; all writes are confined to this project."""

import logging
import os
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[1]
# Keep library caches inside the user's authorized project directory.
os.environ.setdefault("HF_HOME", str(ROOT / "data/cache/huggingface"))
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / "data/cache/matplotlib"))


def load_config():
    for directory in [
        "data/raw",
        "data/processed",
        "data/database",
        "data/cache",
        "reports/figures",
        "logs",
    ]:
        (ROOT / directory).mkdir(parents=True, exist_ok=True)
    try:
        from dotenv import load_dotenv

        load_dotenv(ROOT / ".env", override=False)
    except ImportError:
        pass
    c = yaml.safe_load((ROOT / "config/config.yaml").read_text())
    c["asset"] = os.getenv("ASSET_SYMBOL", c["asset"])
    c["asset_name"] = os.getenv("ASSET_NAME", c["asset_name"])
    c["demo"] = os.getenv("DEMO_MODE", "true").lower() == "true"
    if c["interval"] != "1h" or c["horizon_steps"] != 6:
        raise ValueError(
            "This validated implementation requires interval=1h and six horizons"
        )
    if not 0 < c["initial_train_fraction"] < 1:
        raise ValueError("initial_train_fraction must be between zero and one")
    if c["step_size"] != c["test_window"]:
        raise ValueError(
            "Use step_size=test_window for contiguous, unique OOS predictions"
        )
    if min(c["transaction_cost"], c["slippage"]) < 0:
        raise ValueError("Costs must be nonnegative")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[
            logging.FileHandler(ROOT / "logs/pipeline.log"),
            logging.StreamHandler(),
        ],
    )
    return c
