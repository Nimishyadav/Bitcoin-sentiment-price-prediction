"""Headless professional report figures."""

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from src.config import ROOT


def generate(features, predictions, backtest, metrics, demo):
    plt.style.use("seaborn-v0_8-whitegrid")
    tag = "DEMO synthetic" if demo else "Historical OOS"
    paths = []

    def save(fig, name):
        fig.suptitle(tag, fontsize=10, color="darkred" if demo else "black")
        fig.tight_layout(rect=[0, 0, 1, 0.96])
        path = ROOT / "reports/figures" / f"{name}.png"
        fig.savefig(path, dpi=140, bbox_inches="tight")
        plt.close(fig)
        paths.append(path.name)

    fig, ax = plt.subplots(figsize=(11, 4))
    ax.plot(features.timestamp, features.close, color="navy")
    ax.set_ylabel("Asset price (USD)")
    ax2 = ax.twinx()
    ax2.plot(features.timestamp, features.sentiment_mean, color="orange", alpha=0.6)
    ax2.set_ylabel("X sentiment [-1,1]")
    ax.set_title("X sentiment and price")
    save(fig, "sentiment_price")
    fig, ax = plt.subplots(figsize=(11, 4))
    ax.plot(features.timestamp, features.sentiment_mean.rolling(24).mean())
    ax.set(title="24-hour rolling X sentiment", ylabel="Mean score")
    save(fig, "sentiment_trend")
    fig, ax = plt.subplots(figsize=(11, 4))
    ax.plot(features.timestamp, features.post_count)
    ax.set(title="X posts per hour", ylabel="Posts")
    save(fig, "post_volume")
    for h in range(6):
        g = predictions[(predictions.model == "tree") & (predictions.horizon == h)]
        fig, ax = plt.subplots(figsize=(11, 4))
        ax.plot(g.target_timestamp, g.actual, label="Actual")
        ax.plot(g.target_timestamp, g.predicted, label="Tree forecast", alpha=0.8)
        ax.set(title=f"n+{h}: {h+1}-hour ahead close", ylabel="USD")
        ax.legend()
        save(fig, f"actual_predicted_n{h}")
    g = predictions[(predictions.model == "tree") & (predictions.horizon == 0)]
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.scatter(g.actual / g.close - 1, g.predicted / g.close - 1, s=10, alpha=0.5)
    ax.set(title="n+0 returns", xlabel="Actual return", ylabel="Predicted return")
    save(fig, "returns_scatter")
    g = backtest[(backtest.model == "tree") & (backtest.horizon == 0)]
    eq = (1 + g.strategy_return).cumprod()
    bh = (1 + g.buy_hold_return).cumprod()
    fig, ax = plt.subplots(figsize=(11, 4))
    ax.plot(g.timestamp, eq, label="Tree strategy after costs")
    ax.plot(g.timestamp, bh, label="Buy and hold")
    ax.legend()
    ax.set(title="n+0 strategy equity", ylabel="Growth of 1")
    save(fig, "equity")
    dd = eq / np.maximum.accumulate(np.r_[1, eq])[1:] - 1
    fig, ax = plt.subplots(figsize=(11, 4))
    ax.fill_between(g.timestamp, dd, 0, alpha=0.5)
    ax.set(title="n+0 strategy drawdown", ylabel="Drawdown")
    save(fig, "drawdown")
    cols = [
        "log_return_1",
        "rolling_volatility",
        "sentiment_mean",
        "weighted_sentiment_mean",
        "post_count",
    ]
    corr = features[cols].corr()
    fig, ax = plt.subplots(figsize=(8, 6))
    im = ax.imshow(corr, vmin=-1, vmax=1, cmap="coolwarm")
    ax.set_xticks(range(len(cols)), cols, rotation=40, ha="right")
    ax.set_yticks(range(len(cols)), cols)
    fig.colorbar(im, ax=ax)
    ax.set_title("Descriptive feature correlation (not fitted preprocessing)")
    save(fig, "heatmap")
    fig, ax = plt.subplots(figsize=(9, 4))
    for model, g in metrics.groupby("model"):
        ax.plot(g.horizon, g.RMSE, marker="o", label=model)
    ax.set(
        title="Out-of-sample error by horizon", xlabel="Horizon n+", ylabel="RMSE (USD)"
    )
    ax.legend()
    save(fig, "horizon_comparison")
    return paths
